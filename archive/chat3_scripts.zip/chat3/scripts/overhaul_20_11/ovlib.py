"""Overhaul helpers: load every session into a 1 Hz series (cached as npz)."""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/tk")
import cp_lib as cp
OV = "/home/claude/ov"; CACHE = OV + "/cache"; os.makedirs(CACHE, exist_ok=True)
FTP_MONTH = {"2026-08": 170.0, "2026-09": 170.0, "2026-10": 170.0, "2026-11": 175.0}   # 20 Nov: Sep 170 (not 165): 22 Sep held 170.0 W for 60 min (stops excl.) = floor

def ctx():
    return pd.read_csv(OV + "/data/session_context.csv", dtype={"id": str})

def _run10():
    src = open("/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/run_10_11.py").read()
    ns = {}; exec(src.split("assert")[0], ns); t, d, hr = (np.array(ns[k], float) for k in ("t", "d", "hr"))
    T = np.arange(int(t[-1]) + 1); D = np.interp(T, t, d); H = np.interp(T, t, hr)
    H[D < 1300] = np.nan; H[H < 100] = np.nan
    gap = np.zeros(len(T), bool)
    for a, b in zip(t[:-1], t[1:]):
        if b - a > 30: gap[int(a):int(b)] = True
    return T, D, H, gap

def load(row):
    """-> dict(kind, t (s), P, H, C, D, V, mov (bool), lat, lon) at 1 Hz; P/C NaN for runs."""
    key = "%s_%s" % (row["date"], row["id"]); fn = CACHE + "/" + key + ".npz"
    if os.path.exists(fn):
        z = np.load(fn); return {k: z[k] for k in z.files} | {"kind": row["kind"]}
    if row["file"] == "stream:run_10_11":
        T, D, H, gap = _run10(); n = len(T); V = np.full(n, np.nan); V[15:n - 15] = (D[30:] - D[:n - 30]) / 30
        out = dict(t=T.astype(float), P=np.full(n, np.nan), H=H, C=np.full(n, np.nan), D=D, V=V, mov=~gap, lat=np.array([50.8249]), lon=np.array([6.9108]))
    elif row["kind"] == "run":
        r = cp.run_1hz(OV + "/" + row["file"]); n = r["n"]
        a, ex = cp._at().load_any(OV + "/" + row["file"])
        out = dict(t=r["T"].astype(float), P=np.full(n, np.nan), H=r["H"], C=np.full(n, np.nan), D=r["D"], V=r["V"], mov=~r["stop"], lat=a[:1, 1], lon=a[:1, 2])
    else:
        a, ex, tl = cp.load_activity(OV + "/" + row["file"]); n = len(tl["rec"])
        P = np.where(tl["rec"], np.nan_to_num(tl["P"]), 0.0); H = np.asarray(tl["H"], float); C = np.asarray(tl["C"], float)
        S = np.nan_to_num(tl["S"]); D = np.asarray(tl["D"], float)
        if row["kind"] == "vride": mov = tl["rec"] & ((P > 0) | (S >= 1.0))
        else: mov = tl["rec"] & (S >= 1.0)
        lat = a[np.isfinite(a[:, 1]), 1][:1] if np.isfinite(a[:, 1]).any() else np.array([np.nan])
        lon = a[np.isfinite(a[:, 2]), 2][:1] if np.isfinite(a[:, 2]).any() else np.array([np.nan])
        out = dict(t=np.arange(n, dtype=float), P=P, H=H, C=C, D=D, V=S, mov=mov, lat=lat, lon=lon)
    np.savez_compressed(fn, **out); out["kind"] = row["kind"]; return out

MANUAL_BAD = {"2026-09-05": [(20, 36)], "2026-09-10": [(13, 58)], "2026-09-29": [(55, 57.5)], "2026-10-17": [(0, 999)],
              "2026-10-23": [(22, 31)], "2026-10-26": [(17.3, 20.7)]}

def clean_hr(x, row):
    """HR with strap artefacts blanked: manual ranges (coach notes), hr_artefact_scan hits (+-1 min), hr_gaps, and 1-2 s jumps of
    more than 15 bpm (+-10 s). Returns (H_clean, list of blanked (from_min, to_min), share of moving seconds blanked or missing)."""
    H = np.asarray(x["H"], float).copy(); n = len(H); bad = list(MANUAL_BAD.get(row["date"], []))
    if row["kind"] != "run":
        tl = dict(P=x["P"], H=H, S=np.where(x["mov"], 2.0, 0.0))
        bad += [(a - 1, b + 1) for a, b, k in cp.hr_artefact_scan(tl)]
    d = np.abs(np.diff(H, prepend=H[0])); d2 = np.abs(H - np.roll(H, 2)); jump = np.where((d > 15) | (d2 > 15))[0]
    for j in jump:
        if 5 < j < n - 5: H[max(0, j - 10):j + 10] = np.nan
    for a, b in bad: H[int(max(0, a) * 60):int(min(n / 60, b) * 60)] = np.nan
    m = x["mov"]; share = float(1 - np.isfinite(H[m]).mean()) if m.any() else 1.0
    return H, bad, share
