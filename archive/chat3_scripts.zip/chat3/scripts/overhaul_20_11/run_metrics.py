import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import ovlib as ov, metrics as mt, hrm
CLEAN = {}
for sp in ("ride", "run"):
    for s_ in hrm.build(sp)["data"]: CLEAN[(s_["r"]["date"], s_["r"]["id"])] = (s_["H"], s_["resid_blank"])
c = ov.ctx(); rows = []
for _, r in c.iterrows():
    x = ov.load(r); ftp = ov.FTP_MONTH[r["date"][:7]]; x["H"], bad, sh = ov.clean_hr(x, r); rb = 0.0
    if (r["date"], r["id"]) in CLEAN: x["H"], rb = CLEAN[(r["date"], r["id"])]
    d = dict(date=r["date"], id=r["id"], kind=r["kind"], src=r["src"], ftp=ftp if r["kind"] != "run" else np.nan)
    d.update(mt.run_load(x) if r["kind"] == "run" else mt.ride_load(x, ftp)); d.update(mt.hr_stats(x)); d["hr_bad_pct"] = (sh + rb) * 100; d.update(mt.decoupling(x, r["kind"], ftp))
    d["ef"] = mt.ef(x, r["kind"]); ev = mt.hrr(x, r["kind"], ftp)
    for cat in ("mod", "max"):
        v = [e[2] for e in ev if e[3] == cat]; d["hrr_" + cat + "_n"] = len(v); d["hrr_" + cat + "_avg"] = np.mean(v) if v else np.nan; d["hrr_" + cat + "_best"] = max(v) if v else np.nan
    rows.append(d)
m = pd.DataFrame(rows)
KM = {"2026-11-07": 30.8, "2026-11-11": 33.1, "2026-11-12": 34.8, "2026-11-14": 34.1, "2026-11-15": 28.5, "2026-11-17": 45.8, "2026-11-18": 37.9}
for d, k in KM.items(): m.loc[m["date"] == d, "km"] = k
m.to_csv("/home/claude/ov/data/metrics_v1.csv", index=False)
pd.set_option("display.width", 260); pd.set_option("display.max_rows", 100)
cols = ["date", "kind", "hr_bad_pct", "sec", "km", "avg_w", "np_w", "IF", "tss", "easy_pct", "cad", "hr_avg", "hr_max", "hr30", "dec", "dec_flag", "ef", "hrr_mod_n", "hrr_mod_avg", "hrr_mod_best", "hrr_max_n", "hrr_max_avg", "hrr_max_best"]
print(m[cols].round(2).to_string())
