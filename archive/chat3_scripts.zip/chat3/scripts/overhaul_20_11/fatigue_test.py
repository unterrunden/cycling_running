import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import hrm
F = pd.read_csv("data/factors.csv", dtype={"id": str})
for sport in ("ride", "run"):
    M = hrm.build(sport); print(sport, "coef k1 %.1f k2 %.1f drift %.3f" % tuple(M["coef"]))
    rows = [dict(date=s["r"]["date"], id=s["r"]["id"], b=s["b"], rmse=s["rmse"], n=s["n_ok"]) for s in M["data"]]
    B = pd.DataFrame(rows).merge(F, on=["date", "id"]); B.to_csv("data/offsets_%s.csv" % sport, index=False)
    if sport == "run": print(B[["date", "b", "rmse", "temp", "feel", "notes"]].round(1).to_string()); continue
    B = B[np.isfinite(B["b"]) & (B["n"] >= 600)].copy()
    B["nofan"] = (B["fancat"] == "nofan").astype(float); B["oldfan"] = (B["fancat"] == "oldfan").astype(float); B["indoor"] = (B["fancat"] != "out").astype(float)
    B["feel_d"] = B["feel"] - 5; B["t_c"] = B["temp"] - 18
    def loo(cols):
        X = np.column_stack([np.ones(len(B))] + [B[c].values for c in cols]); y = B["b"].values; err = []
        for i in range(len(B)):
            m = np.arange(len(B)) != i; cf, *_ = np.linalg.lstsq(X[m], y[m], rcond=None); err.append(y[i] - X[i] @ cf)
        cf, *_ = np.linalg.lstsq(X, y, rcond=None)
        return float(np.sqrt(np.mean(np.square(err)))), cf
    base = ["t_c", "nofan", "oldfan", "indoor", "feel_d"]
    print("SD of offsets %.2f, n %d" % (B["b"].std(), len(B)))
    for cols in ([], ["t_c"], ["t_c", "indoor"], ["t_c", "indoor", "nofan", "oldfan"], base, base + ["tsb"], base + ["atl"], base + ["prev1"], base + ["prev3"], base + ["ctl"], base + ["tsb", "ctl"], base + ["dur"]):
        e, cf = loo(cols); print("  %-60s LOO RMSE %.2f  coef %s" % (",".join(cols) or "(mean only)", e, np.round(cf, 3)))
    print(B[["date", "b", "rmse", "temp", "fancat", "feel", "tsb", "prev1"]].round(1).to_string())
