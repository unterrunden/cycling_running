"""Session inventory + context for the 20 Nov overhaul -> data/session_context.csv"""
import sys; sys.path.insert(0, "/home/claude/tk")
import cp_lib as cp, pandas as pd, numpy as np
df = cp.load_activities_csv("/home/claude/ov/exp/activities.csv")
s = df[(df["date"] >= "2026-09-01") | (df["type"] == "Run")].copy()
rows = []
for _, r in s.iterrows():
    kind = {"Ride": "ride", "Virtual Ride": "vride", "Run": "run"}[r["type"]]
    rows.append(dict(id=str(r["id"]), date=r["date"], start_local=str(r["start_local"])[:19], kind=kind, src="E", file="exp/" + r["file"],
                     rpe=r["rpe"], rpe_src="strava" if pd.notna(r["rpe"]) else "", desc=r["desc"] if isinstance(r["desc"], str) else ""))
ctx = pd.DataFrame(rows)
# 7 Nov: the Edge file (Stages, full timeline) replaces the MyWhoosh file
ctx.loc[ctx["date"] == "2026-11-07", ["file", "src"]] = ["files/07_11_garmin.fit", "F"]
extra = [  # after the export (files from the chat; 10 Nov run: hand-copied connector stream)
 dict(id="20934398125", date="2026-11-10", start_local="2026-11-10T15:51:00", kind="run", src="C", file="stream:run_10_11", rpe=3, rpe_src="strava"),
 dict(id="20950533954", date="2026-11-11", start_local="2026-11-11T18:24:00", kind="vride", src="F", file="files/11_11_garmin.fit", rpe=5, rpe_src="chat"),
 dict(id="20962904394", date="2026-11-12", start_local="2026-11-12T18:19:52", kind="vride", src="F", file="files/12_11_garmin.fit", rpe=8, rpe_src="chat (7/8/9 at 20/40/60 min)"),
 dict(id="20988747551", date="2026-11-14", start_local="2026-11-14T18:51:00", kind="vride", src="F", file="files/14_11_garmin.fit", rpe=3, rpe_src="chat"),
 dict(id="21000768907", date="2026-11-15", start_local="2026-11-15T17:45:58", kind="vride", src="F", file="files/15_11_garmin.fit", rpe=7, rpe_src="est (efforts 9.5, easy parts)"),
 dict(id="21025115416", date="2026-11-17", start_local="2026-11-17T18:29:52", kind="vride", src="F", file="files/17_11_garmin.fit", rpe=6, rpe_src="chat (check 5, interval 6)"),
 dict(id="21036964956", date="2026-11-18", start_local="2026-11-18T17:09:08", kind="vride", src="F", file="files/18_11_garmin.fit", rpe=7, rpe_src="est (30 s 9.5, intervals 6.5)"),
 dict(id="21059503183", date="2026-11-20", start_local="2026-11-20T15:20:45", kind="vride", src="F", file="files/20_11_garmin.fit", rpe=6, rpe_src="chat"),
]
ctx = pd.concat([ctx, pd.DataFrame(extra)], ignore_index=True)
ctx.loc[ctx["date"] == "2026-11-01", ["rpe", "rpe_src"]] = [8, "est (4DP: 5 min 9, 20 min 8.5, 1 min 9.9)"]
# feel 0-10 (5 = average), from Pat's statements in the chats; default 5
feel = {"2026-10-12": (3, "felt poor (warm, after travel)"), "2026-10-14": (7, "felt good"), "2026-10-23": (4, "cold 19-25 Oct (school trip)"),
        "2026-10-26": (5, "after the cold"), "2026-10-28": (6, "5K, stitches only minor"), "2026-11-01": (8, "very solid, best in weeks"),
        "2026-11-08": (6, "quite solid"), "2026-11-10": (4, "off day: slight headache, stitches, thigh ache"), "2026-11-11": (6, "energy solid, manageable"),
        "2026-11-12": (9, "overall feeling 9.5/10"), "2026-11-14": (8, "felt really good, legs 9.5"), "2026-11-15": (5, "legs tired after the efforts"),
        "2026-11-17": (4, "legs solid but not optimal"), "2026-11-18": (5, ""), "2026-11-20": (5, "feel 5, legs 8, sleep 7.5 h")}
ctx["feel"] = [feel.get(d, (5, ""))[0] for d in ctx["date"]]; ctx["feel_note"] = [feel.get(d, (5, ""))[1] for d in ctx["date"]]
ctx["feel_src"] = ["chat" if d in feel else "default" for d in ctx["date"]]
# indoor environment: fan and room temperature (start, end; None = estimate later)
fan = {"2026-11-03": "none", "2026-11-04": "weak", "2026-11-06": "weak", "2026-11-07": "none", "2026-11-08": "none", "2026-11-11": "old",
       "2026-11-12": "L3", "2026-11-14": "L1", "2026-11-15": "L1/L3/L2", "2026-11-17": "L1/L2", "2026-11-18": "L1/L2", "2026-11-20": "L1/L2"}
room = {"2026-11-11": (15.1, 16.8), "2026-11-12": (15.0, 19.2), "2026-11-17": (16.0, 19.0), "2026-11-20": (16.0, None)}
ctx["fan"] = [fan.get(d, "") if k == "vride" else "" for d, k in zip(ctx["date"], ctx["kind"])]
ctx["room_start"] = [room.get(d, (None, None))[0] for d in ctx["date"]]; ctx["room_end"] = [room.get(d, (None, None))[1] for d in ctx["date"]]
notes = {"2026-10-12": "Bibbona (IT), warm, after travel", "2026-10-14": "Bibbona (IT), reps", "2026-10-23": "Leutkirch (680 m), cold 19-25 Oct, strap artefact, frozen HR min 22-31",
         "2026-10-26": "Leutkirch (680 m), frozen HR min 17.3-20.7", "2026-10-16": "strap dropouts", "2026-10-17": "HR not usable (strap)",
         "2026-11-01": "4DP test", "2026-11-12": "hour test (test part only recorded)", "2026-11-10": "HR invalid before km 1.3 (strap)",
         "2026-09-05": "HR artefact min 20-36", "2026-09-10": "HR missing / artefact min 13-58", "2026-09-29": "HR drop at km 1.2-1.4 and min 55-57", "2026-09-12": "no HR first 7.5 min"}
ctx["notes"] = [notes.get(d, "") for d in ctx["date"]]
ctx = ctx.sort_values(["date", "start_local"]).reset_index(drop=True)
ctx.to_csv("/home/claude/ov/data/session_context.csv", index=False)
print(ctx[["date", "kind", "src", "file", "rpe", "rpe_src", "feel", "fan"]].to_string()); print(len(ctx), "sessions;", (ctx["rpe_src"] == "").sum(), "without RPE")
