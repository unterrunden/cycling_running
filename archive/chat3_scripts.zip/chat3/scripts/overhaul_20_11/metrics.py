"""Per-session metrics (draft of the cp_lib METRICS section)."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import ovlib as ov
RIDE_Z = (132, 148, 162, 177); RUN_Z = (150, 164, 173, 188)          # HR zone lower bounds of Z2..Z5 (ride: inclusive upper edges +1)
RIDE_Z5, RIDE_Z3 = 178, 149; RUN_Z5, RUN_Z3 = 188, 164
THR_PACE = 300.0                                                      # run threshold pace s/km (intervals.icu 5:00)

def roll(x, w):
    x = np.nan_to_num(np.asarray(x, float)); c = np.cumsum(np.concatenate([[0], x])); out = np.full(len(x), np.nan)
    if len(x) >= w: out[w - 1:] = (c[w:] - c[:-w]) / w
    return out

def norm_power(p):
    r = roll(p, 30); r = r[np.isfinite(r)]
    return float(np.mean(r ** 4) ** 0.25) if len(r) else np.nan

def ride_load(x, ftp):
    m = x["mov"]; P = x["P"][m]; sec = int(m.sum())
    if sec < 120 or np.nanmax(P) <= 0: return dict(sec=sec)
    NP = norm_power(P); IF = NP / ftp; avg = float(np.mean(P))
    return dict(sec=sec, km=float(np.nanmax(x["D"]) / 1000) if np.isfinite(x["D"]).any() else np.nan, avg_w=avg, np_w=NP, IF=IF,
                tss=sec * NP * IF / (ftp * 3600) * 100, vi=NP / avg if avg > 0 else np.nan,
                easy_pct=float(np.mean(P <= 0.77 * ftp) * 100), z3_pct=float(np.mean((P > 0.77 * ftp) & (P <= 0.90 * ftp)) * 100),
                z4_pct=float(np.mean(P > 0.90 * ftp) * 100), cad=float(np.nanmean(x["C"][m][x["C"][m] > 0])) if (x["C"][m] > 0).any() else np.nan)

def run_load(x, thr=THR_PACE):
    m = x["mov"]; sec = int(m.sum()); V = np.nan_to_num(x["V"])[m]
    if sec < 120: return dict(sec=sec)
    ns = float(np.mean(np.clip(roll(V, 30)[29:], 0, None) ** 4) ** 0.25)    # normalised speed (NP analogue; flat courses, no grade adjustment)
    IF = ns / (1000 / thr); dist = float(np.nanmax(x["D"]) - np.nanmin(x["D"]))
    return dict(sec=sec, km=dist / 1000, pace=sec / dist * 1000, ns_pace=1000 / ns, IF=IF, tss=sec / 3600 * IF ** 2 * 100)

def hr_stats(x):
    m = x["mov"]; H = x["H"][m]; ok = np.isfinite(H)
    if ok.mean() < 0.5: return dict(hr_avg=np.nan, hr_max=np.nan, hr30=np.nan, hr_cover=float(ok.mean()))
    r30 = roll(np.where(np.isfinite(x["H"]), x["H"], np.nan), 30)
    return dict(hr_avg=float(np.nanmean(H)), hr_max=float(np.nanmax(H)), hr30=float(np.nanmax(r30)), hr_cover=float(ok.mean()))

def decoupling(x, kind, ftp=None):
    """Pw:HR (rides, NP per half) or speed:HR (runs) over the moving part without the warm-up (rides 10 min, runs 5 min) and the end
    (rides 5 min, runs 2 min); halves by moving time. Flags: u = under 20 min (runs 15 min) usable or under 85% valid HR;
    i = efforts / intervals (30-s power above 105% FTP for more than 5% of the time), IF above 0.90, or halves whose NP differ by more than 8%; s = under 40 min usable."""
    skip, tail, need = (300, 120, 900) if kind == "run" else (600, 300, 1200)
    m = np.where(x["mov"])[0]
    if len(m) < skip + tail + need: return dict(dec=np.nan, dec_flag="u")
    m = m[skip:len(m) - tail]; h1, h2 = m[:len(m) // 2], m[len(m) // 2:]; H = x["H"]
    if np.isfinite(H[m]).mean() < 0.85: return dict(dec=np.nan, dec_flag="u")
    if kind == "run": e = lambda idx: np.nanmean(np.nan_to_num(x["V"])[idx]) / np.nanmean(H[idx])
    else: e = lambda idx: norm_power(x["P"][idx]) / np.nanmean(H[idx])
    dec = (e(h1) / e(h2) - 1) * 100; flag = ""
    if kind != "run":
        P = x["P"][m]; hard = np.mean(roll(P, 30)[29:] > 1.05 * ftp)
        n1, n2 = norm_power(x["P"][h1]), norm_power(x["P"][h2])
        if norm_power(P) / ftp > 0.90 or hard > 0.05 or abs(n1 / n2 - 1) > 0.08: flag = "i"
    if flag == "" and len(m) < (1800 if kind == "run" else 2400): flag = "s"
    return dict(dec=float(dec), dec_flag=flag)


def ef(x, kind):
    m = x["mov"]; H = x["H"][m]
    if np.isfinite(H).mean() < 0.85: return np.nan
    if kind == "run": return float(np.nanmean(np.nan_to_num(x["V"])[m]) * 60 / np.nanmean(H))   # m/min per bpm
    return float(norm_power(x["P"][m]) / np.nanmean(H))

def hrr(x, kind, ftp=None, sep_s=90):
    """1-min HR recoveries. Effort end = 20-s mean intensity >= 90% FTP (ride) / pace <= 5:30/km (run) followed by 60 s of recovery
    (ride: 60-s mean <= 65% FTP and no 10-s mean above 75% FTP, or rolling / standing; run: walking, standing or jog slower than 7:30/km).
    HRR = HR peak within -5..+15 s of the effort end minus HR 60 s after that peak. Counted only from HR >= Z3; max = from Z5."""
    H = x["H"]; n = len(H); out = []
    if kind == "run":
        I = np.nan_to_num(x["V"]); hi = roll(I, 20) >= 1000 / 330; lowmax = 1000 / 450; z3, z5 = RUN_Z3, RUN_Z5
    else:
        I = np.nan_to_num(x["P"]); hi = roll(I, 20) >= 0.90 * ftp; lowmax = 0.65 * ftp; z3, z5 = RIDE_Z3, RIDE_Z5
    last = -10 ** 9; t = 20
    while t < n - 80:
        if hi[t] and not hi[t + 1]:
            nxt = I[t + 1:t + 61]
            if kind == "run": rec = np.nanmean(nxt) <= lowmax
            else: rec = (np.mean(nxt) <= lowmax) and (np.nanmax(roll(nxt, 10)) <= 0.75 * ftp)
            if rec and t - last > sep_s:
                w = H[max(0, t - 5):t + 16]
                if np.isfinite(w).sum() >= 15:
                    pk = max(0, t - 5) + int(np.nanargmax(w)); hp = H[pk]
                    seg = H[pk:pk + 66]
                    smooth = np.isfinite(seg).sum() >= 60 and np.nanmax(np.abs(np.diff(seg[np.isfinite(seg)]))) <= 6
                    if pk + 60 < n and smooth and hp >= z3:
                        h60 = np.nanmean(H[pk + 58:pk + 63]); out.append((t, float(hp), float(hp - h60), "max" if hp >= z5 else "mod")); last = t
        t += 1
    return out

def pmc(daily, start, end, ctl_days=42, atl_days=7):
    """daily: {date: TSS}. Returns DataFrame(date, tss, ctl, atl, tsb) with TSB = yesterday's CTL - ATL (form going into the day)."""
    days = pd.date_range(start, end, freq="D"); ctl = atl = 0.0; rows = []
    for d in days:
        k = d.strftime("%Y-%m-%d"); t = daily.get(k, 0.0); tsb = ctl - atl
        ctl += (t - ctl) / ctl_days; atl += (t - atl) / atl_days; rows.append(dict(date=k, tss=t, ctl=ctl, atl=atl, tsb=tsb))
    return pd.DataFrame(rows)
