import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); sys.path.insert(0, "/home/claude/tk"); import ovlib as ov, cp_lib as cp
SEC = {"5s": 5, "15s": 15, "30s": 30, "1min": 60, "2min": 120, "3min": 180, "5min": 300, "8min": 480, "10min": 600, "15min": 900, "20min": 1200, "30min": 1800,
       "45min": 2700, "60min": 3600, "90min": 5400, "120min": 7200, "150min": 9000}
def best(P, w):
    if len(P) < w: return np.nan
    c = np.cumsum(np.concatenate([[0], P])); return float((c[w:] - c[:-w]).max() / w)
c = ov.ctx(); rows = []
a = cp.load_activities_csv(ov.OV + "/exp/activities.csv")
aug = a[(a.date >= "2026-08-29") & (a.date < "2026-09-01") & (a.type == "Ride")]
extra = [dict(date=r.date, id=str(r.id), kind="ride", file="exp/" + r.file, src="E") for r in aug.itertuples()]
for r in list(c[c.kind != "run"].to_dict("records")) + extra:
    x = ov.load(r); P = np.nan_to_num(x["P"])
    if P.max() <= 0: continue
    meter = "Stages" if (r["kind"] == "ride" or str(r["file"]).startswith("files/")) else "KICKR"
    d = dict(date=r["date"], id=r["id"], kind=r["kind"], meter=meter, src=r["src"])
    for k, w in SEC.items(): d["el_" + k] = best(P, w); d["ro_" + k] = best(P[x["mov"]], w)
    rows.append(d)
B = pd.DataFrame(rows).sort_values("date"); B.to_csv("data/bests.csv", index=False)
for grp, g in B.groupby(["kind", "meter"]):
    print(grp, len(g))
    for k in SEC:
        e = g["el_" + k]; ro = g["ro_" + k]
        if e.notna().any(): print("  %-6s el %6.1f %s   ro %6.1f %s" % (k, e.max(), g.loc[e.idxmax(), "date"], ro.max(), g.loc[ro.idxmax(), "date"]))
