import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import ovlib as ov, metrics as mt, hrmodel as hm

def lowpass2(I, t_on, t_off):
    y = np.empty(len(I)); acc = 0.0
    for i, v in enumerate(I):
        a = 1.0 / (t_on if v > acc else t_off); acc += a * (v - acc); y[i] = acc
    return y

def fit(data, t_on, t_off, t_slow, clip):
    Xs, ys, gid = [], [], []
    for g, s in enumerate(data):
        I = np.minimum(s["I"], clip); f = lowpass2(I, t_on, t_off); fs = hm.lowpass(I, t_slow) if t_slow else None; o = s["ok"]
        cols = [f[o], s["t"][o]] + ([fs[o]] if t_slow else []); Xs.append(np.column_stack(cols)); ys.append(s["H"][o]); gid.append(np.full(o.sum(), g))
    X = np.vstack(Xs); y = np.concatenate(ys); gid = np.concatenate(gid); Xd = X.copy(); yd = y.copy()
    for g in range(len(data)):
        m = gid == g; Xd[m] -= X[m].mean(0); yd[m] -= y[m].mean()
    coef, *_ = np.linalg.lstsq(Xd, yd, rcond=None); res = yd - Xd @ coef
    per = [float(np.sqrt(np.mean(res[gid == g] ** 2))) for g in range(len(data))]
    return float(res.std()), coef, float(np.median(per))

base = hm.build(("ride", "vride"), taus=(30,)); data = base["data"]
res = []
for t_on in (20, 30, 45):
    for t_off in (30, 60, 90):
        for t_slow in (0, 300, 900):
            for clip in (1.0, 1.15, 1.3):
                sd, coef, med = fit(data, t_on, t_off, t_slow, clip); res.append((sd, med, t_on, t_off, t_slow, clip, np.round(coef, 3)))
res.sort(key=lambda r: r[0])
for r in res[:8]: print("SD %.2f  median session RMSE %.2f  on %d off %d slow %d clip %.2f coef %s" % r)
print("simple model: SD %.2f" % base["sd"])
