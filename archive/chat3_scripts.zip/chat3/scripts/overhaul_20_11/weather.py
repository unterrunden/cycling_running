import sys, json, urllib.request, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import ovlib as ov
c = ov.ctx(); rows = []
for _, r in c.iterrows():
    if r["kind"] == "vride": continue
    x = ov.load(r); lat, lon = float(x["lat"][0]), float(x["lon"][0])
    st = pd.Timestamp(r["start_local"]); dur_h = len(x["t"]) / 3600
    url = ("https://archive-api.open-meteo.com/v1/archive?latitude=%.3f&longitude=%.3f&start_date=%s&end_date=%s&timezone=Europe%%2FBerlin"
           "&hourly=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,wind_gusts_10m,precipitation,cloud_cover,shortwave_radiation" % (lat, lon, r["date"], r["date"]))
    j = json.load(urllib.request.urlopen(url, timeout=30))["hourly"]
    hrs = pd.to_datetime(j["time"]); h0 = st.replace(tzinfo=None); sel = (hrs >= h0.floor("h")) & (hrs <= (h0 + pd.Timedelta(hours=dur_h)).ceil("h"))
    g = lambda k: float(np.nanmean(np.array(j[k], float)[sel]))
    rows.append(dict(date=r["date"], id=r["id"], lat=round(lat, 3), lon=round(lon, 3), temp=round(g("temperature_2m"), 1), apparent=round(g("apparent_temperature"), 1),
                     rh=round(g("relative_humidity_2m")), wind_kmh=round(g("wind_speed_10m"), 1), gust_kmh=round(g("wind_gusts_10m"), 1),
                     precip_mm=round(float(np.nansum(np.array(j["precipitation"], float)[sel])), 1), cloud=round(g("cloud_cover")), rad=round(g("shortwave_radiation"))))
w = pd.DataFrame(rows); w.to_csv("/home/claude/ov/data/weather_cache.csv", index=False); print(w.to_string())
