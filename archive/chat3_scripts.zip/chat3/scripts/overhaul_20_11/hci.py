"""HCI (HR consistency index, 0-100): how well HR matched the achieved power (rides) or pace (runs), with the context counted in partly.
Steps: (1) pooled within-session HR model per sport (hrm.py) -> session HR offset b_s, within-session RMSE, predicted HR;
(2) context expectation c_s from the factors (temperature, fan, feel, fatigue = ATL, RPE vs expected, altitude, illness);
(3) components: level L = b_s - reference (raw) or - reference - c_s (adjusted); dynamics R = within-session RMSE; zone agreement Z
(HR zone vs zone of the predicted HR, adjacent zone = half credit); (4) badness D = 0.45 |L|/med + 0.35 R/med + 0.20 (1-Z)/med;
D = (1 - a) D_raw + a D_adj with a = 0.35 + 0.25 min(1, |c_s| / 8); (5) percentile of D within the reference set -> score via the anchors."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import hrm
ANCH = np.array([(0, 15), (2.5, 30), (10, 55), (25, 67), (50, 75), (75, 82), (90, 88), (97.5, 93), (100, 97)], float)
W = dict(L=0.45, R=0.35, Z=0.20); RPE_W = 0.5            # RPE: half of the fitted (shrunk) coefficient = 'small factor / cross-check' [Pat]
ZE = dict(ride=[132.5, 148.5, 162.5, 177.5], run=[149.5, 163.5, 172.5, 187.5])
PRIOR = dict(ill=3.0, alt_per_km=2.0)                    # [mine] priors (not estimable from the data yet): illness +3 bpm, altitude +2 bpm per 1000 m above home
MIN_SCORE_S, MIN_OK_S, MAX_BLANK = 120, 300, 0.30
F = pd.read_csv("data/factors.csv", dtype={"id": str}); CF = pd.read_csv("data/hci_ctx_coef.csv").set_index("name")["used"]
RPE_A = tuple(pd.read_csv("data/hci_rpe_coef.csv")["coef"])   # RPE expected = a + b IF + c ln(h) (rides, hci_ctx.py)

def context(f, kind, run_rpe_mean=0.0):
    """Expected HR offset (bpm) from the factors, relative to the reference condition (18 C, outdoors / new fan, feel 5, ATL 35, RPE as expected)."""
    rpe_dev = f.rpe - (RPE_A[0] + RPE_A[1] * f.IF + RPE_A[2] * np.log(f.dur / 60)) if np.isfinite(f.rpe) and np.isfinite(f.IF) else 0.0
    if kind == "run": rpe_dev -= run_rpe_mean
    t = (f.temp - 18) if np.isfinite(f.temp) else 0.0
    parts = dict(temp=CF["t_c"] * t, fan=CF["nofan"] * (f.fancat == "nofan") + CF["oldfan"] * (f.fancat == "oldfan"), feel=CF["feel_d"] * (f.feel - 5),
                 fatigue=CF["atl_d"] * (f.atl - 35), rpe=RPE_W * CF["rpe_dev"] * rpe_dev,
                 alt=PRIOR["alt_per_km"] * max(0.0, (f.alt_m - 65) / 1000), ill=PRIOR["ill"] * f.ill)
    return float(sum(parts.values())), parts

def zone_credit(H, Hp, edges):
    zh, zp = np.searchsorted(edges, H), np.searchsorted(edges, Hp); d = np.abs(zh - zp)
    return float(np.mean(np.where(d == 0, 1.0, np.where(d == 1, 0.5, 0.0))))

def components():
    rows = []
    for sport in ("ride", "run"):
        M = hrm.build(sport); Fk = F.set_index(["date", "id"])
        runs = F[F.kind == "run"]; rpe_run = np.mean([(r.rpe - (RPE_A[0] + RPE_A[1] * r.IF + RPE_A[2] * np.log(r.dur / 60))) for r in runs.itertuples()])
        tmp = []
        for s in M["data"]:
            r = s["r"]; f = Fk.loc[(r["date"], r["id"])]; c, parts = context(f, r["kind"], rpe_run if sport == "run" else 0.0)
            tmp.append(dict(date=r["date"], id=r["id"], kind=r["kind"], n_ok=s["n_ok"], blank=s["bad_share"] + s["resid_blank"], b=s["b"], R=s["rmse"], c=c,
                            **{"c_" + k: v for k, v in parts.items()}, indoor=float(f.fancat != "out"), s=s))
        T = pd.DataFrame(tmp)
        ok = T.n_ok >= 600
        if sport == "ride":
            ref = lambda row: CF["intercept"] + CF["indoor"] * row.indoor
        else:
            base = float(np.mean((T.b - T.c)[ok])); ref = lambda row: base
        for row in T.itertuples():
            s = row.s; o = s["ok"]; rf = ref(row)
            if row.n_ok < MIN_SCORE_S or not np.isfinite(row.b):
                rows.append(dict(date=row.date, id=row.id, kind=row.kind, n_ok=row.n_ok, blank=row.blank, flag="-")); continue
            Zr = zone_credit(s["H"][o], (s["pred0"] + rf)[o], ZE[sport]); Za = zone_credit(s["H"][o], (s["pred0"] + rf + row.c)[o], ZE[sport])
            flag = "u" if (row.n_ok < MIN_OK_S or row.blank > MAX_BLANK) else ""
            d = dict(date=row.date, id=row.id, kind=row.kind, n_ok=row.n_ok, blank=row.blank, b=row.b, ref=rf, c=row.c, L_raw=row.b - rf, L_adj=row.b - rf - row.c,
                     R=row.R, Z_raw=Zr, Z_adj=Za, flag=flag)
            d.update({k: getattr(row, k) for k in T.columns if k.startswith("c_")}); rows.append(d)
    return pd.DataFrame(rows)

def score_table(C, ref_D=None, scales=None):
    v = C[C.flag.isin(["", "u"])].copy()
    if scales is None:
        g = v[v.flag == ""]; scales = dict(L=float(np.median(np.abs(g.L_raw))), R=float(np.median(g.R)), Z=float(np.median(1 - g.Z_raw)))
    bad = lambda L, R, Z: W["L"] * np.abs(L) / scales["L"] + W["R"] * R / scales["R"] + W["Z"] * (1 - Z) / scales["Z"]
    v["D_raw"] = bad(v.L_raw, v.R, v.Z_raw); v["D_adj"] = bad(v.L_adj, v.R, v.Z_adj)
    v["alpha"] = 0.35 + 0.25 * np.minimum(1, np.abs(v.c) / 8); v["D"] = (1 - v.alpha) * v.D_raw + v.alpha * v.D_adj
    if ref_D is None: ref_D = np.sort(v.loc[v.flag == "", "D"].values)
    v["pct"] = [pct(x, ref_D) for x in v.D]; v["HCI"] = np.interp(v.pct, ANCH[:, 0], ANCH[:, 1])
    v["HCI_raw"] = np.interp([pct(x, ref_D) for x in v.D_raw], ANCH[:, 0], ANCH[:, 1]); v["HCI_adj"] = np.interp([pct(x, ref_D) for x in v.D_adj], ANCH[:, 0], ANCH[:, 1])
    out = C.merge(v[["date", "id", "D_raw", "D_adj", "alpha", "D", "pct", "HCI", "HCI_raw", "HCI_adj"]], on=["date", "id"], how="left")
    return out, ref_D, scales

def pct(x, ref):
    """Goodness percentile of badness x against the sorted reference (mid-rank; lower badness = higher percentile), linear between order statistics."""
    n = len(ref); pos = 100 * (n - 0.5 - np.arange(n)) / n          # plotting positions: best (lowest D) -> highest percentile
    if x < ref[0]: return float(pos[0] + (100 - pos[0]) * min(1, (ref[0] - x) / ref[0]))
    if x > ref[-1]: return float(pos[-1] * max(0.0, 1 - (x - ref[-1]) / (0.5 * ref[-1])))
    return float(np.interp(x, ref, pos))

if __name__ == "__main__":
    C = components(); S, ref_D, scales = score_table(C)
    S.to_csv("data/hci.csv", index=False); pd.DataFrame(dict(D=ref_D)).to_csv("data/hci_reference.csv", index=False)
    print("scales", {k: round(v, 3) for k, v in scales.items()}, "reference n", len(ref_D))
    pd.set_option("display.width", 250)
    print(S[["date", "kind", "n_ok", "blank", "b", "ref", "c", "L_raw", "L_adj", "R", "Z_raw", "Z_adj", "alpha", "D", "HCI_raw", "HCI_adj", "HCI", "flag"]].round(2).to_string())
    g = S[S.flag == ""]; print("HCI median %.1f P10 %.1f P90 %.1f min %.1f max %.1f" % (g.HCI.median(), g.HCI.quantile(.1), g.HCI.quantile(.9), g.HCI.min(), g.HCI.max()))
