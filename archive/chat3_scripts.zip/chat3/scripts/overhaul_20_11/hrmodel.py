"""Pooled lagged HR model: HR(t) = b_s + k * f_tau(I)(t) + d * t_min; I = power/FTP (rides, clipped 0-1.3) or speed/threshold speed (runs)."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import ovlib as ov, metrics as mt

def lowpass(I, tau):
    a = 1.0 / tau; y = np.empty(len(I)); acc = I[0] if np.isfinite(I[0]) else 0.0
    for i, v in enumerate(I):
        acc += a * ((0.0 if not np.isfinite(v) else v) - acc); y[i] = acc
    return y

def session_inputs(r, x, thr_pace=mt.THR_PACE):
    if r["kind"] == "run":
        I = np.clip(np.nan_to_num(x["V"]) / (1000 / thr_pace), 0, 1.3)
    else:
        I = np.clip(np.nan_to_num(x["P"]) / ov.FTP_MONTH[r["date"][:7]], 0, 1.3)
    I = np.where(x["mov"], I, 0.0)        # standing: zero intensity
    return I

def build(kinds, taus=(20, 30, 45, 60, 90, 120), skip_s=300):
    c = ov.ctx(); data = []
    for _, r in c.iterrows():
        if r["kind"] not in kinds: continue
        x = ov.load(r)
        if r["kind"] != "run" and np.nanmax(np.nan_to_num(x["P"])) <= 0: continue
        H, bad, sh = ov.clean_hr(x, r); I = session_inputs(r, x)
        ok = np.isfinite(H) & x["mov"]; ok[:skip_s] = False
        if ok.sum() < 600: continue
        data.append(dict(r=r, H=H, I=I, ok=ok, t=np.arange(len(H)) / 60.0))
    best = None
    for tau in taus:
        Xs, ys, gid = [], [], []
        for g, s in enumerate(data):
            f = lowpass(s["I"], tau); o = s["ok"]
            Xs.append(np.column_stack([f[o], s["t"][o]])); ys.append(s["H"][o]); gid.append(np.full(o.sum(), g))
        X = np.vstack(Xs); y = np.concatenate(ys); gid = np.concatenate(gid)
        # within-session demeaning removes the offsets b_s
        Xd = X.copy(); yd = y.copy()
        for g in range(len(data)):
            m = gid == g; Xd[m] -= X[m].mean(0); yd[m] -= y[m].mean()
        coef, *_ = np.linalg.lstsq(Xd, yd, rcond=None); res = yd - Xd @ coef; sd = res.std()
        if best is None or sd < best[0]: best = (sd, tau, coef)
    sd, tau, (k, d) = best
    offs = []
    for s in data:
        f = lowpass(s["I"], tau); o = s["ok"]; pred = k * f + d * s["t"]
        b = float(np.mean(s["H"][o] - pred[o])); s["b"] = b; s["f"] = f; s["pred"] = pred + b
        offs.append(dict(date=s["r"]["date"], id=s["r"]["id"], kind=s["r"]["kind"], b=b, rmse=float(np.sqrt(np.mean((s["H"][o] - s["pred"][o]) ** 2))), n=int(o.sum())))
    return dict(tau=tau, k=k, d=d, sd=sd, data=data, offsets=pd.DataFrame(offs))

if __name__ == "__main__":
    for kinds in (("ride", "vride"), ("run",)):
        m = build(kinds)
        print(kinds, "tau %d s, k %.1f bpm per FTP-unit, drift %.3f bpm/min, residual SD %.2f" % (m["tau"], m["k"], m["d"], m["sd"]))
        print(m["offsets"].round(1).to_string())
