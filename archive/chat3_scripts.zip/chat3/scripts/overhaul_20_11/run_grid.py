import sys, itertools, numpy as np
sys.path.insert(0, "/home/claude/ov"); import hrm
M = hrm.build("run"); data = M["data"]; best = []
for t_on, t_off, t_slow, clip in itertools.product((20, 30, 45, 60), (45, 60, 90, 120), (600, 900, 1200), (1.3, 1.6)):
    p = dict(t_on=t_on, t_off=t_off, t_slow=t_slow, clip=clip)
    for s in data: s["f1"], s["f2"] = hrm.features(s["I"], p)
    use = [s for s in data if s["ok"].sum() >= 300]; cf = hrm._fit(use); e = []
    for s in use:
        o = s["ok"]; pr = cf[0] * s["f1"][o] + cf[1] * s["f2"][o] + cf[2] * s["t"][o]; r = s["H"][o] - pr; e.append(r - r.mean())
    e = np.concatenate(e); best.append((float(np.sqrt(np.mean(e ** 2))), p, np.round(cf, 3)))
best.sort(key=lambda z: z[0]); [print(round(b[0], 3), b[1], b[2]) for b in best[:8]]; print("current", [b for b in best if b[1] == dict(t_on=20, t_off=60, t_slow=900, clip=1.3)][0][0])
