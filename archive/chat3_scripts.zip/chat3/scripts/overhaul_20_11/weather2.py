import sys, json, os, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import ovlib as ov
c = ov.ctx(); rows = []
src = {k: json.load(open("wx/%s.json" % k)) for k in ("bruehl", "bibbona", "leutkirch") if os.path.exists("wx/%s.json" % k) and "hourly" in json.load(open("wx/%s.json" % k))}
for _, r in c.iterrows():
    if r["kind"] == "vride": continue
    x = ov.load(r); lat = float(x["lat"][0]); loc = "bibbona" if lat < 45 else ("leutkirch" if lat < 49 else "bruehl")
    if loc not in src: rows.append(dict(date=r["date"], id=r["id"], loc=loc)); continue
    j = src[loc]["hourly"]; hrs = pd.to_datetime(j["time"]); st = pd.Timestamp(r["start_local"]).replace(tzinfo=None); en = st + pd.Timedelta(seconds=len(x["t"]))
    sel = (hrs >= st.floor("h")) & (hrs <= en.ceil("h") - pd.Timedelta(hours=1)) if (en - st).total_seconds() > 3600 else (hrs == st.round("h"))
    g = lambda k: float(np.nanmean(np.array(j[k], float)[sel]))
    rows.append(dict(date=r["date"], id=r["id"], loc=loc, temp=round(g("temperature_2m"), 1), apparent=round(g("apparent_temperature"), 1), rh=round(g("relative_humidity_2m")),
                     wind_kmh=round(g("wind_speed_10m"), 1), gust_kmh=round(g("wind_gusts_10m"), 1), precip_mm=round(float(np.nansum(np.array(j["precipitation"], float)[sel])), 1),
                     cloud=round(g("cloud_cover")), rad=round(g("shortwave_radiation")), hours=int(sel.sum())))
w = pd.DataFrame(rows); w.to_csv("/home/claude/ov/data/weather_cache.csv", index=False); print(w.to_string())
