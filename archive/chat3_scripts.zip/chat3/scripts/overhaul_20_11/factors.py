import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import ovlib as ov, metrics as mt
m = pd.read_csv("data/metrics_v1.csv", dtype={"id": str}); aug = pd.read_csv("data/aug_tss.csv")
daily = {}
for d, t in zip(aug["date"], aug["tss"]): daily[d] = daily.get(d, 0) + t
for d, t in zip(m["date"], m["tss"]):
    if np.isfinite(t): daily[d] = daily.get(d, 0) + t
P = mt.pmc(daily, "2026-08-07", "2026-11-22"); P.to_csv("data/pmc.csv", index=False)
P = P.set_index("date")
def prev(d, k): return float(sum(daily.get((pd.Timestamp(d) - pd.Timedelta(days=i)).strftime("%Y-%m-%d"), 0) for i in range(1, k + 1)))
c = ov.ctx(); w = pd.read_csv("data/weather_cache.csv", dtype={"id": str})
ILL = {"2026-10-23"}   # [Pat] cold 19-25 Oct (only the 23 Oct run falls inside it)
rows = []
for _, r in c.iterrows():
    mm = m[(m["date"] == r["date"]) & (m["id"] == r["id"])].iloc[0]; dur = mm["sec"] / 60
    if r["kind"] == "vride":
        IF = mm["IF"] if np.isfinite(mm["IF"]) else 0.8
        rs = r["room_start"] if np.isfinite(r["room_start"]) else 15.5
        rise = (r["room_end"] - rs) if np.isfinite(r["room_end"]) else 3.0 * min(1.3, IF / 0.85) * (1 - np.exp(-dur / 45))
        temp = rs + 0.6 * rise
    else:
        ww = w[(w["date"] == r["date"]) & (w["id"] == r["id"])]; temp = float(ww["apparent"].iloc[0]) if len(ww) and np.isfinite(ww["apparent"].iloc[0]) else np.nan
    fan = r["fan"] if isinstance(r["fan"], str) else ""
    fancat = "out" if r["kind"] != "vride" else ("nofan" if fan in ("none", "weak") else ("oldfan" if fan == "old" else "newfan"))
    rows.append(dict(date=r["date"], id=r["id"], kind=r["kind"], temp=temp, fancat=fancat, feel=r["feel"], rpe=r["rpe"], IF=mm["IF"], dur=dur,
                     tsb=P.loc[r["date"], "tsb"], atl=P.loc[r["date"], "atl"] if False else P.loc[(pd.Timestamp(r["date"]) - pd.Timedelta(days=1)).strftime("%Y-%m-%d"), "atl"],
                     ctl=P.loc[(pd.Timestamp(r["date"]) - pd.Timedelta(days=1)).strftime("%Y-%m-%d"), "ctl"], prev1=prev(r["date"], 1), prev3=prev(r["date"], 3),
                     alt_m=680.0 if "Leutkirch" in str(r["notes"]) else (20.0 if "Bibbona" in str(r["notes"]) else 65.0),
                     ill=1.0 if r["date"] in ILL else 0.0, notes=r["notes"]))
F = pd.DataFrame(rows); F.to_csv("data/factors.csv", index=False)
print(F.round(1).to_string())
