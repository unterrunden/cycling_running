"""August load for the PMC seed: rides 7-20 Aug have no power -> TSS = moving h x 0.75^2 x 100 (IF 0.75 assumed); 29-31 Aug from power (FTP 170)."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); sys.path.insert(0, "/home/claude/tk"); import ovlib as ov, metrics as mt, cp_lib as cp
a = cp.load_activities_csv(ov.OV + "/exp/activities.csv"); a = a[(a.date < "2026-09-01")]; rows = []
for r in a.itertuples():
    if r.date >= "2026-08-29":
        x = ov.load(dict(date=r.date, id=str(r.id), kind="ride", file="exp/" + r.file, src="E")); L = mt.ride_load(x, ov.FTP_MONTH["2026-08"])
        rows.append(dict(date=r.date, type=r.type, km=round(r.km, 1), min=round(L["sec"] / 60), tss=round(L["tss"], 1), how="power (FTP 170)"))
    else:
        rows.append(dict(date=r.date, type=r.type, km=round(r.km, 1), min=round(r.moving_s / 60), tss=round(r.moving_s / 3600 * 0.75 ** 2 * 100, 1), how="estimate: moving time x IF 0.75"))
A = pd.DataFrame(rows); A.to_csv("data/aug_tss.csv", index=False); print(A.to_string()); print("total", A.tss.sum())
