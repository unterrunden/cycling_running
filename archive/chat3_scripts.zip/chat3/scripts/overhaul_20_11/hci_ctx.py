"""Context model for the HCI: which factors explain the session HR offset b_s (HR level at a given power after the within-session model)."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import hrm
rng = np.random.default_rng(7)
F = pd.read_csv("data/factors.csv", dtype={"id": str})
M = hrm.build("ride"); R = hrm.build("run")
def offsets(M):
    return pd.DataFrame([dict(date=s["r"]["date"], id=s["r"]["id"], b=s["b"], rmse=s["rmse"], n=s["n_ok"], blank=s["resid_blank"] + s["bad_share"]) for s in M["data"]]).merge(F, on=["date", "id"])
B = offsets(M); B = B[np.isfinite(B.b) & (B.n >= 600)].copy(); BR = offsets(R)
rides = B[B.kind != "run"]
fit_rpe = rides[np.isfinite(rides.rpe)]
Xr = np.column_stack([np.ones(len(fit_rpe)), fit_rpe.IF, np.log(fit_rpe.dur / 60)]); cr, *_ = np.linalg.lstsq(Xr, fit_rpe.rpe, rcond=None)
print("RPE expected = %.2f + %.2f*IF + %.2f*ln(h)" % tuple(cr)); pd.DataFrame(dict(name=["a", "b_IF", "c_lnh"], coef=cr)).to_csv("data/hci_rpe_coef.csv", index=False)
for D in (B, BR):
    D["rpe_dev"] = D.rpe - (cr[0] + cr[1] * D.IF + cr[2] * np.log(D.dur / 60))
    D["indoor"] = (D.fancat != "out").astype(float); D["nofan"] = (D.fancat == "nofan").astype(float); D["oldfan"] = (D.fancat == "oldfan").astype(float)
    D["t_c"] = D.temp - 18; D["feel_d"] = D.feel - 5; D["poor"] = np.maximum(0, 5 - D.feel); D["good"] = np.maximum(0, D.feel - 5)
    D["atl_d"] = D.atl - 35; D["prev1_d"] = D.prev1 / 100
def ols(D, cols):
    X = np.column_stack([np.ones(len(D))] + [D[c].values for c in cols]); y = D.b.values
    cf, *_ = np.linalg.lstsq(X, y, rcond=None); e = y - X @ cf; s2 = e @ e / (len(y) - X.shape[1])
    se = np.sqrt(np.diag(s2 * np.linalg.pinv(X.T @ X))); return cf, se, X, y
def shrink(cf, se, keep=2):
    t = cf / se; f = np.maximum(0, 1 - 1 / np.maximum(t ** 2, 1e-9)); f[:keep] = 1.0; return cf * f, f
def loo(D, cols, shr=False, keep=2):
    err = []
    for i in range(len(D)):
        m = np.arange(len(D)) != i; cf, se, X, y = ols(D.iloc[m], cols)
        if shr: cf, _ = shrink(cf, se, keep)
        x = np.concatenate([[1.0], [D[c].values[i] for c in cols]]); err.append(D.b.values[i] - x @ cf)
    return float(np.sqrt(np.mean(np.square(err))))
print("rides n %d, offset SD %.2f" % (len(B), B.b.std()))
for cols in (["indoor"], ["indoor", "t_c"], ["indoor", "t_c", "nofan", "oldfan"], ["indoor", "t_c", "nofan", "oldfan", "feel_d"], ["indoor", "t_c", "nofan", "oldfan", "poor", "good"],
             ["indoor", "t_c", "nofan", "oldfan", "atl_d"], ["indoor", "t_c", "nofan", "oldfan", "prev1_d"], ["indoor", "t_c", "nofan", "oldfan", "rpe_dev"],
             ["indoor", "t_c", "nofan", "oldfan", "feel_d", "atl_d", "rpe_dev"]):
    print("  %-52s LOO %.2f  LOO(shrunk) %.2f" % (",".join(cols), loo(B, cols), loo(B, cols, True)))
FULL = ["indoor", "t_c", "nofan", "oldfan", "feel_d", "atl_d", "rpe_dev"]
cf, se, X, y = ols(B, FULL); cs, fct = shrink(cf, se)
print("\nfull model (intercept = outdoor at 18 C, feel 5, ATL 35, RPE as expected)")
for n, a, s_, c2, f in zip(["intercept"] + FULL, cf, se, cs, fct): print("  %-10s %7.3f  SE %6.3f  t %5.2f  shrink %.2f -> %7.3f" % (n, a, s_, a / s_, f, c2))
# feel: bootstrap and detectability
fe = []
for _ in range(4000):
    i = rng.integers(0, len(B), len(B)); D = B.iloc[i]
    if D.feel_d.abs().sum() == 0: continue
    c_, *_ = ols(D, FULL); fe.append(c_[FULL.index("feel_d") + 1])
fe = np.array(fe); print("\nfeel coefficient bootstrap: median %.2f, 5-95%% %.2f..%.2f bpm per feel point; share < 0: %.2f" % (np.median(fe), *np.percentile(fe, [5, 95]), np.mean(fe < 0)))
k = FULL.index("feel_d") + 1; print("minimum detectable feel effect (80%% power, 2-sided 5%%): about %.1f bpm per point" % (2.8 * se[k]))
# simulation: if poor feel truly raised HR by beta per point, how often would the data show it (t > 2)?
res_sd = np.sqrt(np.mean((y - X @ cf) ** 2))
for beta in (-1, -2, -3):
    hit = 0
    for _ in range(1000):
        ys = X @ np.where(np.arange(len(cf)) == k, beta, cf) + rng.normal(0, res_sd, len(y))
        c_, *_ = np.linalg.lstsq(X, ys, rcond=None); e = ys - X @ c_; s2 = e @ e / (len(y) - X.shape[1]); s_ = np.sqrt(np.diag(s2 * np.linalg.pinv(X.T @ X)))
        hit += (c_[k] / s_[k] < -2)
    print("  true %+d bpm per feel point below 5 -> detected in %d%% of simulated data sets" % (-beta, hit / 10))
print("sessions with recorded feel (not default):", int((F.feel != 5).sum()), "of", len(F), "; rides in the fit with feel != 5:", int((B.feel != 5).sum()))
B.to_csv("data/hci_ride_offsets.csv", index=False); BR.to_csv("data/hci_run_offsets.csv", index=False)
pd.DataFrame(dict(name=["intercept"] + FULL, coef=cf, se=se, shrink=fct, used=cs)).to_csv("data/hci_ctx_coef.csv", index=False)
print("\nruns:"); print(BR[["date", "b", "rmse", "n", "temp", "feel", "rpe_dev", "alt_m", "ill"]].round(2).to_string())
cfr, ser, *_ = ols(BR[np.isfinite(BR.temp)], ["t_c"]); print("runs b ~ t_c: %.2f (SE %.2f)" % (cfr[1], ser[1]))
