"""Final HR model for the HCI: HR(t) = b_s + k1 * f(I; on 20 s, off 60 s) + k2 * slow(I; 900 s) + d * t_min (+ residual)."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/ov"); import ovlib as ov, metrics as mt
from hrmodel import lowpass, session_inputs
PAR = dict(ride=dict(t_on=20, t_off=60, t_slow=900, clip=1.3), run=dict(t_on=20, t_off=60, t_slow=900, clip=1.3))

def lowpass2(I, t_on, t_off):
    y = np.empty(len(I)); acc = 0.0
    for i, v in enumerate(I):
        acc += (v - acc) / (t_on if v > acc else t_off); y[i] = acc
    return y

def features(I, p):
    I = np.minimum(I, p["clip"]); return lowpass2(I, p["t_on"], p["t_off"]), lowpass(I, p["t_slow"])

def _pad(m, k):
    if k <= 0 or not m.any(): return m
    c = np.convolve(m.astype(float), np.ones(2 * k + 1), "same"); return c > 0

def _fit(use):
    X = np.vstack([np.column_stack([s["f1"][s["ok"]], s["f2"][s["ok"]], s["t"][s["ok"]]]) for s in use])
    y = np.concatenate([s["H"][s["ok"]] for s in use]); gid = np.concatenate([np.full(s["ok"].sum(), g) for g, s in enumerate(use)])
    Xd, yd = X.copy(), y.copy()
    for g in range(len(use)):
        m = gid == g; Xd[m] -= X[m].mean(0); yd[m] -= y[m].mean()
    coef, *_ = np.linalg.lstsq(Xd, yd, rcond=None); return coef

def build(sport, skip_s=300, neg_thr=30.0, pos_thr=40.0):
    kinds = ("run",) if sport == "run" else ("ride", "vride"); p = PAR[sport]; c = ov.ctx(); data = []
    for _, r in c.iterrows():
        if r["kind"] not in kinds: continue
        x = ov.load(r)
        if r["kind"] != "run" and np.nanmax(np.nan_to_num(x["P"])) <= 0: continue
        H, bad, sh = ov.clean_hr(x, r); I = session_inputs(r, x); f1, f2 = features(I, p)
        H = H.copy(); H[H < 40] = np.nan
        ok = np.isfinite(H) & x["mov"]; ok[:skip_s] = False
        data.append(dict(r=r, x=x, H=H, I=I, f1=f1, f2=f2, ok=ok, t=np.arange(len(H)) / 60.0, bad_share=sh, n_mov=int(x["mov"].sum())))
    coef = _fit([s for s in data if s["ok"].sum() >= 600])
    # second pass: residual-based dropout cleaning (strap reading far too low, or isolated spikes far too high)
    for s in data:
        o = s["ok"]
        if o.sum() < 120: s["resid_blank"] = 0.0; continue
        pred0 = coef[0] * s["f1"] + coef[1] * s["f2"] + coef[2] * s["t"]; b = np.nanmedian((s["H"] - pred0)[o])
        res = s["H"] - pred0 - b; lo = np.nan_to_num(res, nan=0) < -neg_thr; hi = np.nan_to_num(res, nan=0) > pos_thr
        bad = _pad(lo, 30) | _pad(hi, 10)
        s["resid_blank"] = float((bad & np.isfinite(s["H"]) & s["x"]["mov"]).sum()) / max(1, s["n_mov"])
        s["H"] = s["H"].copy(); s["H"][bad] = np.nan; s["ok"] = o & ~bad
    coef = _fit([s for s in data if s["ok"].sum() >= 600])
    for s in data:
        o = s["ok"]; pred0 = coef[0] * s["f1"] + coef[1] * s["f2"] + coef[2] * s["t"]
        s["b"] = float(np.mean(s["H"][o] - pred0[o])) if o.sum() >= 120 else np.nan
        s["pred0"] = pred0; s["n_ok"] = int(o.sum())
        s["rmse"] = float(np.sqrt(np.mean((s["H"][o] - pred0[o] - s["b"]) ** 2))) if o.sum() >= 120 else np.nan
    return dict(coef=coef, data=data, par=p)
