import sys, time; sys.path.insert(0, "/home/claude/tk")
import cp_lib as cp
for d, g, k in [("11 Nov", "tests/11_11_garmin.fit", "tests/11_11_kickr.fit"), ("12 Nov", "tests/12_11_garmin.fit", "tests/12_11_kickr.fit"),
                ("14 Nov", "/home/claude/fit_14_11/14_11_garmin.fit", "/home/claude/fit_14_11/14_11_kickr.fit")]:
    t = time.time(); print("=====", d)
    gs, ks = cp.fit_series(g), cp.fit_series(k)
    mo = cp.meter_offset(gs, ks, align="power")
    print(" segments:"); cp.segment_lags(gs, ks)
    print(" %.1f s" % (time.time() - t))
