"""11 Nov 2026 trainer ride: efforts, HR around the max, identical-sample check, RR quality. Uses Pat's cp_lib (repo)."""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo/cycling_running")
import numpy as np, pandas as pd, cp_lib as cp
from fitparse import FitFile

G = '/home/claude/fit_11_11/11_11_garmin.fit'; K = '/home/claude/fit_11_11/11_11_kickr.fit'
LAG = -4  # from meter_offset (KICKR clock vs Edge clock)

def series(path):
    s = cp.fit_series(path)
    df = pd.DataFrame({'t': np.asarray(s['t'], float), 'p': s['p'], 'hr': s['hr'], 'cad': s['cad']})
    return df

g = series(G); k = series(K)
t0 = g.t.iloc[0]
g['m'] = (g.t - t0) / 60
k['t_al'] = k.t + LAG          # KICKR samples moved onto the Edge clock
k['m'] = (k.t_al - t0) / 60

# 1) identical samples: is the Edge power the Stages (not the KICKR)?
mg = g.set_index(g.t.round()).p
mk = k.set_index(k.t_al.round()).p
common = mg.index.intersection(mk.index)
a, b = mg.loc[common].astype(float), mk.loc[common].astype(float)
ok = (a > 50) & (b > 50)
print(f"identical power samples (both > 50 W): {np.mean(a[ok].values == b[ok].values)*100:.1f}% of {ok.sum()}")

# 2) laps from the Edge file
ff = FitFile(G)
laps = [(l.get_value('start_time'), l.get_value('total_elapsed_time')) for l in ff.get_messages('lap')]
import datetime as dt
def epoch(x): return x.replace(tzinfo=dt.timezone.utc).timestamp()

print("\nEfforts per second (Edge/Stages W | KICKR W | cadence | HR):")
for i in (1, 3, 5):
    s0 = epoch(laps[i][0]); dur = laps[i][1]
    seg = g[(g.t >= s0 - 5) & (g.t <= s0 + dur + 45)]
    print(f"\n-- lap {i+1}: start {(s0-t0)/60:.2f} min, {dur:.1f} s --")
    rows = []
    for _, r in seg.iterrows():
        kk = k.loc[(k.t_al - r.t).abs().idxmin()]
        rows.append(f"{r.t - s0:+5.0f}s  S {r.p:4.0f}  K {kk.p:4.0f}  cad {r.cad if not pd.isna(r.cad) else -1:4.0f}  HR {r.hr if not pd.isna(r.hr) else -1:4.0f}/{kk.hr:4.0f}")
    print("\n".join(rows[::2]))

# 3) the 1-min openers
print("\nOpeners (Stages / KICKR 60-s windows at >= 170 W):")
for df, name in ((g, 'Stages'), (k, 'KICKR')):
    p = pd.Series(df.p.values).fillna(0).rolling(60).mean()
    m = df.m.values
    cand = [(m[i], p[i]) for i in range(len(p)) if p[i] >= 170]
    # cluster
    groups, cur = [], []
    for x in cand:
        if cur and x[0] - cur[-1][0] > 0.2: groups.append(cur); cur = []
        cur.append(x)
    if cur: groups.append(cur)
    print(name, [(round(max(gr, key=lambda z: z[1])[0], 1), round(max(z[1] for z in gr))) for gr in groups])

# 4) HR max: top readings and the RR picture
print("\nTop HR readings (Edge | KICKR):", sorted(g.hr.dropna().astype(int))[-8:], "|", sorted(k.hr.dropna().astype(int))[-8:])
i = g.hr.idxmax(); print(f"Edge HR max {g.hr.max():.0f} at min {g.m[i]:.2f}")
win = g[(g.m >= g.m[i] - 1.5) & (g.m <= g.m[i] + 1.0)]
print("Edge HR, -90 s .. +60 s around the max (every 3 s):", list(win.hr.fillna(-1).astype(int).values[::3]))
kw = k[(k.m >= g.m[i] - 1.5) & (k.m <= g.m[i] + 1.0)]
print("KICKR HR same window (every 3 s):            ", list(kw.hr.fillna(-1).astype(int).values[::3]))

# 1-s HR jumps
d = g.hr.diff().abs()
print(f"\nEdge 1-s HR jumps >= 5 bpm: {int((d >= 5).sum())}; >= 8 bpm: {int((d >= 8).sum())}")
dk = k.hr.diff().abs()
print(f"KICKR 1-s HR jumps >= 5 bpm: {int((dk >= 5).sum())}; >= 8 bpm: {int((dk >= 8).sum())}")
for j in g.index[d >= 8][:20]:
    print(f"   Edge jump at min {g.m[j]:.2f}: {g.hr[j-1]:.0f} -> {g.hr[j]:.0f} (P {g.p[j]:.0f} W)")

# 5) RR intervals around the max
rr = []
for msg in FitFile(G).get_messages('hrv'):
    v = msg.get_value('time')
    if v: rr.extend([x for x in v if x is not None])
rr = np.array(rr, float)
ct = np.cumsum(np.where(rr > 3, 0, rr))
print(f"\nRR beats: {len(rr)}, cumulative {ct[-1]/60:.1f} min (timer {4211/60:.1f} min)")
