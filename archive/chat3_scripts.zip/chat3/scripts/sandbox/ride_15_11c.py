import sys; sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo9/cycling_running")
import numpy as np, cp_lib as cp
G, K = "/home/claude/fit_15_11/15_11_garmin.fit", "/home/claude/fit_15_11/15_11_kickr.fit"
gs = cp.fit_series(G); t0, P, H, C = cp._series_1hz(gs)
recs = [m for m in cp._fitfile(G).get_messages("record")]; T = np.array([m.get_value("temperature") for m in recs], float)
print("around the 5-min lap press (Edge s 1180-1215), 1-s power:", P[1180:1215].astype(int).tolist())
print("cadence:", C[1180:1215].astype(int).tolist())
print("best 300 s window s 1189-1489: first 12 s", P[1189:1201].mean().round(1), "W; lap part", P[1201:1489].mean().round(1))
print("after the 5-min lap end (1489-1500):", P[1486:1500].astype(int).tolist())
print("around the 1-min (1960-2035):", P[1960:2035].astype(int).tolist())
# warm-up: efforts > 200 W for >= 10 s
r10 = np.convolve(P, np.ones(10)/10, "same")
print("\nwarm-up / recovery efforts (10-s mean >= 200 W):")
hi = np.where(r10[:1180] >= 200)[0]
if len(hi):
    seg = []; s0 = hi[0]
    for x, y in zip(hi[:-1], hi[1:]):
        if y - x > 5: seg.append((s0, x)); s0 = y
    seg.append((s0, hi[-1]))
    for a, b in seg: print(f"  Edge s {a}-{b} ({b-a+1} s) avg {P[a:b+1].mean():.0f} W max {P[a:b+1].max():.0f}, cad {np.nanmean(C[a:b+1]):.0f}")
print("\n5-min blocks: W, HR, cadence, Edge temp")
for a in range(0, len(P), 300):
    b = min(a + 300, len(P)); print(f"  min {a/60:4.0f}-{b/60:4.0f}: {P[a:b].mean():6.1f} W  HR {np.nanmean(H[a:b]):5.1f}  cad {np.nanmean(C[a:b][C[a:b]>0]):4.0f}  temp {np.nanmean(T[a:b]):4.1f}  zeros {np.sum(P[a:b]==0)}")
# HR recovery after efforts
for name, e in (("5 min", 1489), ("1 min", 2029)):
    print(f"HR after {name}: end {H[e-1]:.0f}, +30 s {H[e+30]:.0f}, +60 s {H[e+60]:.0f}, +120 s {H[e+120]:.0f}, +180 s {H[e+180]:.0f}, +300 s {H[e+300]:.0f}")
# lap 5 HR vs power trend in 5-min chunks
print("\nlap 5 (easy) per 5 min:")
for a in range(2029, 3600, 300):
    b = min(a + 300, 3600); print(f"  s {a}-{b}: {P[a:b].mean():6.1f} W  HR {np.nanmean(H[a:b]):5.1f}  W/HR {P[a:b].mean()/np.nanmean(H[a:b]):.3f}  cad {np.nanmean(C[a:b][C[a:b]>0]):.0f}")
print("warm-up s 300-1150:", round(P[300:1150].mean(), 1), "W HR", round(np.nanmean(H[300:1150]), 1))
# W'
for cp_ in (175, 180):
    w, tau = cp.wbal(P, cp_, 18000, "integral"); wd, _ = cp.wbal(P, cp_, 18000, "differential")
    print(f"CP {cp_}: W'bal with 18 kJ min {w.min()/1000:.1f} (integral) / {wd.min()/1000:.1f} kJ (differential) at Edge s {np.argmin(wd)}; needed:", cp.wprime_needed(P, cp_))
print("implied W' (P-CP)*t: 5 min", [(round((248.0 - c) * 300 / 1000, 1), c) for c in (170, 175, 180)], " 1 min", round((334.0 - 175) * 60 / 1000, 1), " 3 min (14 Nov)", round((258.5 - 175) * 180 / 1000, 1))
best = {60: 334.0, 120: 279.3, 180: 258.5, 300: 248.0, 480: 203.0, 600: 202.2, 900: 187.4, 1200: 183.9, 3600: 175.1}
for m in ("2p",):
    for lo, hi_ in ((120, 1200), (180, 1200), (180, 3600), (300, 3600)):
        f = cp.pd_fit(best, model=m, lo=lo, hi=hi_); print(f"pd_fit {m} {lo}-{hi_} s:", {k: (round(v, 1) if isinstance(v, float) else v) for k, v in f.items() if k in ('cp', 'wprime', 'r2', 'n')})
    f = cp.pd_fit(best, model="2p", lo=120, hi=1200, cp=175); print("CP fixed 175:", {k: (round(v, 1) if isinstance(v, float) else v) for k, v in f.items() if k in ('cp', 'wprime', 'r2', 'n')})
f = cp.pd_fit(best, model="morton", lo=60, hi=3600); print("Morton 3P 60-3600:", {k: (round(v, 1) if isinstance(v, float) else v) for k, v in f.items()})
print("\nHR quality:", cp.hrv_quality(G)[1]); cp.hr_peak_clean(G)
