import numpy as np, pandas as pd
from fitparse import FitFile
G='/home/claude/fit_11_11/11_11_garmin.fit'
rr=[]
for m in FitFile(G).get_messages('hrv'):
    v=m.get_value('time')
    if v: rr.extend([x for x in v if x is not None])
rr=np.array(rr,float); rr=rr[rr<=3]; ct=np.cumsum(rr)
hr=60/rr
# window: cumulative time 55.5-57.5 min (+4 s offset found earlier, pause not removed: the max sits at record min 56.42 -> RR clock about 56.42*60 - 83 + 4?)
# locate by matching: the RR stretch with the highest clean 10-beat mean
med=pd.Series(rr).rolling(7,center=True,min_periods=3).median().values
clean=np.abs(rr-med)/med<=0.12
s=pd.Series(np.where(clean,hr,np.nan))
r5=s.rolling(5,min_periods=5).mean(); r10=s.rolling(10,min_periods=9).mean()
i=int(np.nanargmax(r10.values))
print(f"clean beats {clean.mean()*100:.1f}% of {len(rr)}")
print(f"highest clean 5-beat mean {np.nanmax(r5.values):.1f} bpm, 10-beat mean {np.nanmax(r10.values):.1f} bpm at RR time {ct[i]/60:.2f} min")
print("clean HR around it (every 2nd beat):", [int(round(x)) for x in s.values[i-30:i+30:2] if not np.isnan(x)])
