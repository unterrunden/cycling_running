import re, sys
SRC = "/home/claude/docs/project_memory_mirror.md"; L = open(SRC).read().split("\n")
B = {i: l for i, l in enumerate(L) if l.startswith("- ")}
used = []
def b(i): used.append(i); return B[i]
def split0(text, sep="; "):
    out, depth, cur, k = [], 0, "", 0
    while k < len(text):
        ch = text[k]
        if ch == "(": depth += 1
        elif ch == ")": depth -= 1
        if depth == 0 and text.startswith(sep, k): out.append(cur); cur = ""; k += len(sep); continue
        cur += ch; k += 1
    out.append(cur); return out
def nest_colon(i):
    t = b(i)[2:]; head, rest = t.split(": ", 1); parts = split0(rest)
    return ["- " + head + ":"] + ["  - " + p for p in parts]
def nest_enum(i, pat):
    t = b(i)[2:]; parts = re.split(pat, t); head = parts[0].rstrip().rstrip(";").rstrip()
    keys = re.findall(pat, t); kids = []
    for k, p in zip(keys, parts[1:]): kids.append("  - " + k.strip() + " " + p.strip().rstrip(";").strip())
    return ["- " + head] + kids
E = r"\(\d\)\s" ; A = r"\([a-c]\)\s"
NEW = {
 "ride21": ["- Sat 21 Nov outdoor ride (the first since the 1 Nov 4DP):",
            "  - a great experience with awesome weather (sunny, a beautiful low sun); wore the cycling jacket and long joggers (the long bib tights saved for Sunday), never uncomfortable; quite a few stops",
            "  - overall very strong, felt great and powerful outside, very happy with the HR; went out a bit strong at the start and especially in the last 30-45 min, when he realised he had to speed up to arrive in the light (he barely made it)",
            "  - did not think a front light would be needed yet and slightly underestimated the speed tax of the elevation; the rear light was on throughout",
            "  - legs did not hurt at all, not even when pushing in the last quarter; no pain at any point; a couple of surges, which are very fun",
            "  - uploaded the FIT just in case (as he understood it, not needed for outdoor rides)"],
 "fuel21": ["- 21 Nov fuelling: 1250 ml (the 750 ml steel bottle with about 40 g malto, the 500 ml plastic one with about 1 g salt and nothing else), a croissant and 12 classic Haribo gummy bears; a good meal soon after; never felt undernourished"],
 "line21": ["- 21 Nov session line: feel 8; legs 9/10 (soreness 0); sleep 9 h in total (about 1.5 h on the couch, where he fell asleep, then 7.5 h in bed about 30 min later; nothing negative, no trouble falling asleep); resting HR about 52; room temperature not applicable; nothing special except a bit more food than usual before the ride (not significantly); Claude may look up the weather and wind for the ride from the file's times"],
 "sun22": ["- 21 Nov, tomorrow (Sun 22): mostly zone 2 with only an occasional sprint (like today's surges), no prolonged efforts in zone 3 or above; Claude should not hold back on restricting the ride, but he would like to approach it as initially intended if that is fine given today's form"],
 "swap21": ["- 21 Nov: the weekend swapped back: the outdoor ride on Sat 21 and the long ride on Sun 22, although the other order would have been better: getting the bike out of the trainer and fitting the rear wheel took a while, so 80+ km would not have fitted before dark; should be quicker in future"],
 "rpe21": ["- 21 Nov, RPE: 8 is correct for 1 Nov (it was not on Strava; now added there), about 5 for 15 Nov, 6 for 18 Nov"],
 "agree21": ["- 21 Nov: agrees with the September FTP of 170 W, the tightened HRR rule and a future run threshold test to gauge the relevant metrics; wants the full list of data points Claude needs per session for the analysis and metrics (Claude may ask for more than before)"],
 "strava21": ["- 21 Nov: the 20 Nov Garmin activity on Strava: he moved it to the indoor bike, but cannot change it to 'Virtual Ride' manually; changing it to something like 'Workout' would hide the wattages and power records",
              "- 21 Nov: the 10 Nov run FIT is attached now; nothing committed to GitHub yet (he commits after this update); asked whether the new tests/ folder should hold only the four new files, or whether Claude still wants the older and KICKR files there (both fine)"],
 "docs21": ["- 21 Nov, docs: the overhaul was incredible, expansive work; wishes for the structure:",
            "  - the mirror lost its indented (second-order) bullets and the coach notes many of theirs: use them where beneficial, without overusing them",
            "  - group the bullets of all relevant files into subcategories for each main point (e.g. 'Cycling picture' in the coach notes, 'Tests and benchmarks' here)",
            "  - a further sorting by the date a point was mentioned or added is optional: the files are mainly for Claude, so keep whatever is easiest to digest in new chats",
            "- 21 Nov: wants to start the next main chat likely after Sunday's session, right after the end of week 2 (no preparation needed yet)"],
 "run21": ["- 21 Nov, runs before the tracked ones: about 2 runs a week from February to the end of June, casually training (not very structured) for a 5K school run: 5K from 28:05 on 8 Feb to 25:17 on 14 Jun; the school run itself 25:49 on 2 Jul (a warm day after really hot weeks); then 22 Jul (birthday sub-25 5K, 24:57) and a 2.5 km run in the last full week of the summer break (date unsure, not that relevant); more data on request"],
}
S = []  # output lines
def sec(title): S.extend(["", title])
def sub(title, items):
    S.extend(["", "### " + title])
    for it in items:
        if isinstance(it, int): S.append(b(it))
        elif isinstance(it, str): S.extend(NEW[it])
        else: S.extend(it)
S.extend(L[:13])                     # header, intro, cycling frontmatter (lines 0-12)
sec("## Rider")
sub("Person and home", [14, 15, 21])
sub("Riding style and background", [16, 17])
sub("Nutrition and health", [18, 19, 20, 204])
sec(L[23])
sub("Power and FTP", [24, 25, 26, 46, 32])
sub("HR and zones", [27, 28, 29, 64, 65, 205])
sub("Conventions", [30, 31])
sec("## Gear and accounts")
sub("Bike, devices and kit", [35, 36, 37])
sub("Accounts and subscriptions", [38, 109, 208])
sec("## Bike and trainer status")
sub("Bike", [41, 42])
sub("Trainer, MyWhoosh and recording", [43, 50, 53, 47, 48, 52, 58, 60, 70])
sub("Fan and room", [44, 67, 51, 56, 49, 69, 74, 73, 76, 77])
sub("Trainer sessions 3-11 Nov", [45, 55, 59, 71, 72])
sub("Clothing and nutrition on the bike", [62, 63])
sec("## Tests and benchmarks")
sub("4DP (Sun 1 Nov)", [81, 82, nest_enum(83, E), 84, 85, 164])
sub("Test wishes", [86, 87])
sub("Hour test (Thu 12 Nov)", [54, 68, 88, 89, 90, 91, 150, 149, 92])
sub("Week 1 sessions (13-15 Nov)", [93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103])
sub("Week 2 sessions (17-21 Nov)", [104, 105, 106, 107, 117, 118, 131, "ride21", "fuel21", "line21", "sun22"])
sub("Settings and recording notes (17-20 Nov)", [110, 111, 114, 116, 132])
sub("Segments and test routes", [151, 152, 153, 154, 155, 156, 157])
sec("## Six-week plan")
sub("Setup and workflow", [162, 161, 160, 165, 185])
sub("Goals, content and format", [166, nest_enum(171, A), 167, 168, 169, 183, 184])
sub("Steady state, checks and tests", [172, 173, 174, nest_colon(175), 176])
sub("Runs and the run day", [78, 170, 177, 178, 179, 180, 181])
sub("Long rides and the 100 km", [163, 182])
sub("Week 2 changes (18-21 Nov)", [113, 119, 120, 122, 123, "swap21"])
sub("Side plan and toolkit", [187, 188])
sec("## Routes")
for i in (191, 192, 193, 194, 61, 66): S.append(b(i))
sec("## Data, files and project setup")
sub("Strava, repo and files", [197, 198, 202, 75, 206, 207, 115, "strava21"])
sub("Chats and docs", [200, 201, 57, 203, 199, 148, 112, 186, "docs21"])
sub("History digest and metrics (19-21 Nov)", [121, 124, 125, 126, nest_enum(127, E), 128, nest_enum(129, E), 130, 133, nest_colon(134), 135, 136, 137, 138, 139,
                                               nest_colon(140), 141, 142, 143, 144, 145, nest_colon(146), 147, "rpe21", "agree21"])
S.append(""); S.extend(L[209:215])   # running frontmatter
sec("## Background")
for i in (217, 218, 219, 220): S.append(b(i))
S.extend(NEW["run21"])
sec("## Benchmarks and recent runs")
sub("Times", [223, 225])
sub("Runs in October", [229, 228, 227, 247, 226, 224])
sub("RPE, HR and zones", [230, 231, 232, 233, 108, 234])
sec("## Habits and courses")
sub("Courses", [237, 238])
sub("Habits and recording", [239, 240, 241])
sub("Weekly run in the plan", [242])
sec("## Recent weeks")
for i in (245, 246, 248): S.append(b(i))
S.append(""); S.extend(L[249:255]); S.append("")   # schedule frontmatter
for i in (256, 257, 259, 258): S.append(b(i))
miss = sorted(set(B) - set(used)); dup = sorted(i for i in set(used) if used.count(i) > 1)
print("missing", miss, "dup", dup)
assert not miss and not dup
S[0] = S[0].replace("(20 Nov 2026)", "(21 Nov 2026)")
out = "\n".join(S).replace("\n\n\n", "\n\n").rstrip() + "\n"
open("/home/claude/work21/mirror_new.md", "w").write(out)
print(len(out))
