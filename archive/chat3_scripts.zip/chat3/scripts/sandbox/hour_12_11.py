"""12 Nov 2026 hour test: per-minute power/HR/cadence, pacing phases, HR zones, CP sketches, W/kg, targets derived from the result."""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo6/cycling_running")
import numpy as np, cp_lib as cp

G = '/home/claude/fit_12_11/12_11_garmin.fit'; K = '/home/claude/fit_12_11/12_11_kickr.fit'
t0, P, H, C = cp._series_1hz(cp.fit_series(G))
P, H, C = P[:3600], H[:3600], C[:3600]
pm = P.reshape(60, 60).mean(1); hm = np.nanmean(H.reshape(60, 60), 1); cm = np.nanmean(C.reshape(60, 60), 1)
print("per-minute Stages W:", [int(round(x)) for x in pm])
print("per-minute HR      :", [int(round(x)) for x in hm])
print("per-minute cadence :", [int(round(x)) for x in cm])
print(f"\navg {P.mean():.1f} W; min 0-55 {P[:3300].mean():.1f} W (1-min CV {pm[:55].std()/pm[:55].mean()*100:.1f}%), last 5 min {P[3300:].mean():.1f} W, last 2 min {P[3480:].mean():.1f} W, last 1 min {P[3540:].mean():.1f} W")
for a, b in ((0, 10), (10, 20), (20, 30), (30, 40), (40, 50), (50, 55), (55, 60)):
    print(f"  min {a:2d}-{b:2d}: {P[a*60:b*60].mean():6.1f} W  HR {np.nanmean(H[a*60:b*60]):5.1f} (end {np.nanmean(H[b*60-30:b*60]):5.1f})  cad {np.nanmean(C[a*60:b*60]):4.1f}")
# where was the low phase exactly
r5 = np.convolve(P, np.ones(300) / 300, "valid")
print(f"lowest 5-min window: {r5.min():.1f} W at min {np.argmin(r5)/60:.1f}-{np.argmin(r5)/60+5:.1f}; highest before min 55: {r5[:3000].max():.1f} W")
print(f"seconds below 150 W: {(P < 150).sum()}, at 0 W: {(P == 0).sum()}, above 200 W: {(P > 200).sum()}")
# HR steady part
hs = H[900:3000]
print(f"\nHR min 15-50: mean {np.nanmean(hs):.1f}, range of 5-min means {min(np.nanmean(H[i:i+300]) for i in range(900, 3000, 300)):.1f}-{max(np.nanmean(H[i:i+300]) for i in range(900, 3000, 300)):.1f}")
pz = [0, 132, 148, 162, 177, 999]
hv = H[np.isfinite(H)]
print("HR time in Pat's cycling zones (<=132/133-148/149-162/163-177/>=178):", [f"{((hv > pz[i]) & (hv <= pz[i+1])).mean()*100:.0f}%" for i in range(5)])
# efficiency: W per beat in the steady part vs the first 15 min
print(f"W/HR min 15-50: {P[900:3000].mean()/np.nanmean(H[900:3000]):.3f}")
# CP sketches (work = CP*t + W')
def cp2(p1, t1, p2, t2):
    c = (p2 * t2 - p1 * t1) / (t2 - t1); return c, p1 * t1 - c * t1
for name, (p1, t1) in {"5 min 231 W (1 Nov)": (231, 300), "20 min 184 W (1 Nov)": (184, 1200)}.items():
    c, w = cp2(p1, t1, 175.1, 3600)
    print(f"CP from {name} + 60 min 175.1 W: CP {c:.1f} W, W' {w/1000:.1f} kJ")
c, w = cp2(231, 300, 184, 1200); print(f"CP from 5 + 20 min (1 Nov): CP {c:.1f} W, W' {w/1000:.1f} kJ  (CP below a measured 60-min power => the 1 Nov 5/20 min were not maximal)")
print(f"60/20 ratio vs the 1 Nov 20 min: {175.1/184:.3f}")
for kg in (56, 60):
    print(f"W/kg at {kg} kg: FTP {175/kg:.2f}, 20 min 184 {184/kg:.2f}, 5 min 231 {231/kg:.2f}")
ftp = 175
print("\nStrava-style power zones at FTP 175 (0-55/56-75/76-90/91-105/106-120/121-150/>150 %):",
      [round(ftp * f, 1) for f in (.55, .75, .90, 1.05, 1.20, 1.50)])
for lab, lo, hi in (("week 2 (90-94%)", .90, .94), ("weeks 3-4 (92-96%)", .92, .96), ("week 5 (95-99%)", .95, .99)):
    print(f"  intervals {lab}: {ftp*lo:.0f}-{ftp*hi:.0f} W")
print(f"  20-min test pacing: 100-103% {ftp:.0f}-{ftp*1.03:.0f} W, then 104-107% {ftp*1.04:.0f}-{ftp*1.07:.0f} W")
print(f"  easy cap 75-77%: {ftp*.75:.0f}-{ftp*.77:.0f} W; Z2 target 66-71%: {ftp*.66:.0f}-{ftp*.71:.0f} W")
