import sys; sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo9/cycling_running")
import numpy as np, cp_lib as cp
G, K = "/home/claude/fit_15_11/15_11_garmin.fit", "/home/claude/fit_15_11/15_11_kickr.fit"
gs, ks = cp.fit_series(G), cp.fit_series(K)
t0, P, H, C = cp._series_1hz(gs); u0, Q, HK, CK = cp._series_1hz(ks)
n = len(P); print("Edge", n, "s; KICKR", len(Q), "s; KICKR start - Edge start", u0 - t0, "s")
# resistance field and speed on the Edge (FE-C control?)
recs = [m for m in cp._fitfile(G).get_messages("record")]
res = np.array([m.get_value("resistance") or 0 for m in recs], float); spd = np.array([m.get_value("enhanced_speed") or 0 for m in recs], float)
print("Edge resistance field: unique", np.unique(res)[:10], " temperature", np.unique([m.get_value("temperature") for m in recs]))
laps = cp.fit_laps(G)
L = [(int(round((cp._local(None) if False else 0))))]
starts = np.cumsum([0] + list(laps["elapsed_s"]))
print("lap starts (Edge s):", [round(x) for x in starts])
def align(a, b, w=60):  # best lag of KICKR around Edge window [a,b): returns offset k so that Q[i - (u0-t0) + k] ~ P[i]
    best = (-2, 0)
    for k in range(-150, 151):
        ia = a - (u0 - t0) + k
        if ia - w < 0 or ia + (b - a) + w > len(Q): continue
        x = P[a - w:b + w]; y = Q[ia - w:ia + (b - a) + w]
        r = np.corrcoef(x, y)[0, 1]
        if r > best[0]: best = (r, k)
    return best
for name, a, b in (("5 min", int(starts[1]), int(starts[2])), ("1 min", int(starts[3]), int(starts[4]))):
    r, k = align(a, b); ia = a - (u0 - t0) + k
    p, q, h, c = P[a:b], Q[ia:ia + (b - a)], H[a:b], C[a:b]
    print(f"\n== {name} lap: Edge s {a}-{b} ({b-a} s), KICKR aligned with k {k:+d} (r {r:.3f})")
    print(f"  avg Stages {p.mean():.1f} W, KICKR {q.mean():.1f} W (ratio {q.mean()/p.mean():.3f}), cadence {np.nanmean(c[c>0]):.0f}, HR start {H[a]:.0f} end {np.nanmean(H[b-5:b]):.0f} max {np.nanmax(H[a:b+60]):.0f}, zeros {np.sum(p==0)}")
    step = 30 if b - a > 120 else 10
    print(f"  per {step} s Stages:", [int(round(p[i:i+step].mean())) for i in range(0, b - a - step + 1, step)])
    print(f"  per {step} s KICKR :", [int(round(q[i:i+step].mean())) for i in range(0, b - a - step + 1, step)])
    print(f"  per {step} s cad   :", [int(round(np.nanmean(c[i:i+step]))) for i in range(0, b - a - step + 1, step)])
    print(f"  per {step} s HR    :", [int(round(np.nanmean(h[i:i+step]))) for i in range(0, b - a - step + 1, step)])
    print(f"  KICKR SD of 1-s values {q.std():.1f} W; seconds within +-3 W of the median {np.mean(np.abs(q-np.median(q))<=3)*100:.0f}%; Edge resistance field during lap: {np.unique(res[a:b])}")
    if step == 30: print("  per minute Stages:", [round(p[i:i+60].mean(), 1) for i in range(0, b - a - 59, 60)], " KICKR:", [round(q[i:i+60].mean(), 1) for i in range(0, b - a - 59, 60)])
# best windows on both (elapsed)
for s in (5, 10, 15, 20, 30, 60, 120, 180, 240, 300, 360, 480, 600, 1200):
    a_ = np.convolve(P, np.ones(s)/s, "valid"); b_ = np.convolve(Q, np.ones(s)/s, "valid")
    print(f"best {s:>4} s: Stages {a_.max():6.1f} W (from Edge s {np.argmax(a_)})  KICKR {b_.max():6.1f} W")
