"""Normalise exported Project docs: CRLF -> LF, whitespace-only lines -> empty, blank line before headings (outside code fences)."""
import sys

def normalize(src, dst):
    text = open(src, encoding="utf-8").read().replace("\r\n", "\n").replace("\r", "\n")
    out, fence = [], False
    for line in text.split("\n"):
        line = line.rstrip()
        if line.startswith("```"):
            fence = not fence
        if not fence and line.startswith("#") and out and out[-1] != "":
            out.append("")
        out.append(line)
    while out and out[-1] == "":
        out.pop()
    open(dst, "w", encoding="utf-8").write("\n".join(out) + "\n")

if __name__ == "__main__":
    for s, d in zip(sys.argv[1::2], sys.argv[2::2]):
        normalize(s, d)
        print(d)
