"""11 Nov ride, part 2: trainer speed/resistance on the Edge around the efforts, wind-up before sprint 1, RR around the HR max."""
import sys, datetime as dt
sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo/cycling_running")
import numpy as np, pandas as pd, cp_lib as cp
from fitparse import FitFile

G = '/home/claude/fit_11_11/11_11_garmin.fit'
recs = []
for m in FitFile(G).get_messages('record'):
    v = {f.name: f.value for f in m}
    recs.append(v)
g = pd.DataFrame(recs)
g['t'] = g.timestamp.apply(lambda x: x.replace(tzinfo=dt.timezone.utc).timestamp())
t0 = g.t.iloc[0]; g['m'] = (g.t - t0) / 60
g['kmh'] = g.enhanced_speed * 3.6
print("resistance values (Edge FE-C):", g.resistance.describe().round(1).to_dict())
print("resistance unique (first 20):", sorted(g.resistance.dropna().unique())[:20])

def show(a, b, step=2):
    seg = g[(g.m >= a) & (g.m <= b)]
    for _, r in seg.iloc[::step].iterrows():
        print(f"  min {r.m:6.2f}  S {r.power if not pd.isna(r.power) else -1:4.0f} W  cad {r.cadence if not pd.isna(r.cadence) else -1:4.0f}  "
              f"trainer {r.kmh if not pd.isna(r.kmh) else -1:5.1f} km/h  res {r.resistance if not pd.isna(r.resistance) else -1:4.0f}  HR {r.heart_rate if not pd.isna(r.heart_rate) else -1:4.0f}")

print("\nWind-up before sprint 1 (lap press at 55.98):"); show(55.0, 56.05, 3)
print("\nSprint 2 (lap press at 61.33):"); show(61.25, 61.8, 1)
print("\nSprint 3 (lap press at 65.70):"); show(65.65, 66.0, 1)

# best windows by the Stages around the first sprint
p = g.power.fillna(0).values
for w in (5, 15, 20, 30, 60):
    r = pd.Series(p).rolling(w).mean()
    i = int(r.idxmax())
    print(f"Stages best {w:2d} s: {r.max():.0f} W ending min {g.m[i]:.2f}")

# RR-based HR around the max (min 55-57.5)
rr = []
for msg in FitFile(G).get_messages('hrv'):
    v = msg.get_value('time')
    if v: rr.extend([x for x in v if x is not None])
rr = np.array(rr, float); rr = rr[rr <= 3]
ct = np.cumsum(rr)
# align RR clock to record clock: find offset by best match of RR-derived HR with record HR
hr_rr = 60 / rr
def rr_hr_at(tsec, off):
    idx = np.searchsorted(ct + off, tsec)
    return hr_rr[max(0, min(idx, len(hr_rr) - 1))]
rec_t = (g.t - t0).values; rec_hr = g.heart_rate.values.astype(float)
best = None
for off in range(-120, 121, 2):
    est = np.array([rr_hr_at(x, off) for x in rec_t[::10]])
    ok = ~np.isnan(rec_hr[::10])
    err = np.nanmedian(np.abs(est[ok] - rec_hr[::10][ok]))
    if best is None or err < best[1]: best = (off, err)
off = best[0]; print(f"\nRR clock offset {off} s (median |HR_rr - HR_record| {best[1]:.1f} bpm) -- the Edge timer pause (83 s) is not removed here, so use only as a local check")
# local check around the max
tmax = (g.t[g.heart_rate.idxmax()] - t0)
sel = (ct + off >= tmax - 60) & (ct + off <= tmax + 30)
seg = rr[sel]
med = pd.Series(seg).rolling(7, center=True, min_periods=3).median()
art = np.abs(seg - med) / med > 0.25
print(f"RR around the max (-60..+30 s): {len(seg)} beats, artefacts {art.mean()*100:.1f}%, shortest RR {seg.min():.3f} s = {60/seg.min():.0f} bpm, "
      f"5-beat max {pd.Series(60/seg).rolling(5).mean().max():.1f} bpm")
print("RR-derived HR (every 4th beat):", [int(round(x)) for x in (60 / seg)[::4]])

# whole-ride RR quality via the toolkit
df, summ = cp.hrv_quality(G)
print("\nhrv_quality summary:", summ)
print(df[df.flag].head(15).to_string() if df.flag.any() else "no flagged windows")
