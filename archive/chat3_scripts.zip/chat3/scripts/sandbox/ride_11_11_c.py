"""11 Nov ride, part 3 (after Pat's note: KICKR power cable pulled out during effort 2):
cable-cut window, power-based alignment for the sprints, meter comparison without the dead stretch, sprint windows on both meters,
HR in the 130 W block per 5 min, Pw:HR decoupling."""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo/cycling_running")
import numpy as np, pandas as pd, cp_lib as cp

G = '/home/claude/fit_11_11/11_11_garmin.fit'; K = '/home/claude/fit_11_11/11_11_kickr.fit'
gs = cp.fit_series(G); ks = cp.fit_series(K)
g = pd.DataFrame({'t': np.asarray(gs['t'], float), 'p': gs['p'], 'hr': gs['hr'], 'cad': gs['cad']}).astype(float)
k = pd.DataFrame({'t': np.asarray(ks['t'], float), 'p': ks['p'], 'hr': ks['hr'], 'cad': ks['cad']}).astype(float)
t0 = g.t.iloc[0]

# 1-s grid on the Edge clock
grid = np.arange(g.t.iloc[0], g.t.iloc[-1] + 1)
def on_grid(df, col, shift=0.0):
    s = pd.Series(df[col].values, index=(df.t + shift).round().values)
    s = s[~s.index.duplicated()]
    return s.reindex(grid)
G_p = on_grid(g, 'p'); G_hr = on_grid(g, 'hr')

# cable cut: KICKR power 0 while the Stages shows power, from lap 4 (min 61.33 on the Edge clock)
K_p4 = on_grid(k, 'p', -4)
m = (grid - t0) / 60
after = (m > 61.3)
zero = (K_p4 == 0) & after
# first KICKR sample > 20 W after min 61.5
back = np.where((m > 61.5) & (K_p4.values > 20))[0]
print(f"KICKR power back at Edge min {m[back[0]]:.2f}" if len(back) else "KICKR power not back")
cut = (m >= 61.30) & (m < (m[back[0]] + 0.5 if len(back) else 99))
print(f"masked window: min 61.30 to {m[back[0]] + 0.5:.2f} ({cut.sum()} s)")

# power-based lag in the sprint windows
def best_lag(win):
    a = G_p[win].fillna(0).values
    best = None
    for lag in range(-15, 6):
        b = on_grid(k, 'p', lag)[win].fillna(0).values
        r = np.corrcoef(a, b)[0, 1]
        if best is None or r > best[1]: best = (lag, r)
    return best
w1 = (m > 55.5) & (m < 56.8); w3 = (m > 65.5) & (m < 66.1)
print("power lag sprint 1:", best_lag(w1), " sprint 3:", best_lag(w3), " (HR-based lag was -4 s)")
whole = (m > 11) & (m < 61.2)
print("power lag over min 11-61:", best_lag(whole))

# meter comparison without the dead stretch (HR lag -4, as meter_offset)
mask_t = set(grid[cut])
g2 = {k_: [v for v, tt in zip(gs[k_], gs['t']) if round(tt) not in mask_t] for k_ in ('p', 'hr', 'cad')}
g2['t'] = [tt for tt in gs['t'] if round(tt) not in mask_t]
k2 = {k_: [v for v, tt in zip(ks[k_], ks['t']) if round(tt - 4) not in mask_t] for k_ in ('p', 'hr', 'cad')}
k2['t'] = [tt for tt in ks['t'] if round(tt - 4) not in mask_t]
print("\n=== meter_offset without the cable-cut window ===")
cp.meter_offset(g2, k2)

# sprint windows on both meters (KICKR power-aligned per sprint)
def best(series, w, win):
    s = pd.Series(series[win].fillna(0).values).rolling(w).mean()
    return s.max()
for name, win, lag in (("sprint 1 (lap 2)", w1, best_lag(w1)[0]), ("effort 3 (lap 6)", w3, best_lag(w3)[0])):
    kp = on_grid(k, 'p', lag)
    print(f"\n{name} (KICKR shifted {lag} s):")
    for w in (1, 5, 10, 15, 20):
        a, b = best(G_p, w, win), best(kp, w, win)
        print(f"  best {w:2d} s: Stages {a:4.0f} W  KICKR {b:4.0f} W  ratio {b/a:.3f}")
# openers
print("\nOpeners (best 60 s within each, KICKR power-aligned over min 11-61):")
lagw = best_lag(whole)[0]; kp = on_grid(k, 'p', lagw)
for a_, b_ in ((46.0, 48.0), (50.0, 52.0)):
    win = (m > a_) & (m < b_)
    sa, sb = best(G_p, 60, win), best(kp, 60, win)
    print(f"  min {a_:.0f}-{b_:.0f}: Stages {sa:.0f} W  KICKR {sb:.0f} W  ratio {sb/sa:.3f}")

# 130 W block: HR per 5 min (Edge HR; block from KICKR min 10.8 = Edge min ~10.8 + 0.45 start offset - 1.4 pause?)
# use the Stages/KICKR power to locate it on the Edge clock instead: 30-s mean within 120-140 W (KICKR) for >= 15 min
K_p = on_grid(k, 'p', -4); kp30 = K_p.rolling(30, min_periods=20).mean()
inblk = (kp30 > 119.5) & (kp30 < 139.5)
idx = np.where(inblk.values)[0]
runs, start = [], idx[0]
for a_, b_ in zip(idx[:-1], idx[1:]):
    if b_ - a_ > 5: runs.append((start, a_)); start = b_
runs.append((start, idx[-1]))
s0, s1 = max(runs, key=lambda r: r[1] - r[0])
print(f"\n130 W block on the Edge clock: min {m[s0]:.1f}-{m[s1]:.1f} ({(s1-s0)/60:.1f} min)")
for a_ in range(s0, s1, 300):
    b_ = min(a_ + 300, s1)
    print(f"  min {m[a_]:5.1f}-{m[b_]:5.1f}: KICKR {K_p.values[a_:b_].mean():5.1f} W  Stages {G_p.values[a_:b_].mean():5.1f} W  "
          f"HR {np.nanmean(G_hr.values[a_:b_]):5.1f}  cad {np.nanmean(on_grid(g,'cad').values[a_:b_]):4.0f}")
# 150 W block straight after
b0 = s1 + 1; b1 = b0 + 600
print(f"  150 W part min {m[b0]:.1f}-{m[b1]:.1f}: KICKR {np.nanmean(K_p.values[b0:b1]):.1f} W, HR first/last 5 min "
      f"{np.nanmean(G_hr.values[b0:b0+300]):.1f} / {np.nanmean(G_hr.values[b1-300:b1]):.1f}")
# Pw:HR decoupling over the steady 30 min (130 + 150 W): first half vs second half
seg_p = K_p.values[s0:b1]; seg_h = G_hr.values[s0:b1]; h = len(seg_p) // 2
ef1 = np.nanmean(seg_p[:h]) / np.nanmean(seg_h[:h]); ef2 = np.nanmean(seg_p[h:]) / np.nanmean(seg_h[h:])
print(f"  (130 W block only) decoupling: {((np.nanmean(K_p.values[s0:s0+(s1-s0)//2])/np.nanmean(G_hr.values[s0:s0+(s1-s0)//2])) / (np.nanmean(K_p.values[s0+(s1-s0)//2:s1])/np.nanmean(G_hr.values[s0+(s1-s0)//2:s1])) - 1)*100:+.1f}%")

# HR sources: Edge (ANT+) vs MyWhoosh (BLE) jumps, same strap
k_hr = on_grid(k, 'hr', -4)
both = ~np.isnan(G_hr.values) & ~np.isnan(k_hr.values)
print(f"\nHR Edge vs MyWhoosh on the same seconds: mean diff {np.mean(k_hr.values[both]-G_hr.values[both]):+.2f} bpm, "
      f"MAD {np.median(np.abs(k_hr.values[both]-G_hr.values[both])):.1f}")
print("ride averages: Edge HR", round(np.nanmean(G_hr.values), 1), " Stages W (moving, >0 incl. coasting)", round(np.nanmean(G_p.values), 1))
