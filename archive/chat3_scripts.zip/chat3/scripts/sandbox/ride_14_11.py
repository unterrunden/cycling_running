"""14 Nov 2026 indoor Z2 ride (hilly MyWhoosh course, gradient feel 5-10%), final 3-min push: totals, distribution, efforts,
steady-part HR / decoupling, final effort vs W' model, meter comparison (power-aligned), data quality."""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo7/cycling_running")
import numpy as np, cp_lib as cp

G = '/home/claude/fit_14_11/14_11_garmin.fit'; K = '/home/claude/fit_14_11/14_11_kickr.fit'
gs, ks = cp.fit_series(G), cp.fit_series(K)
t0, P, H, C = cp._series_1hz(gs); tk, PK, HK, CK = cp._series_1hz(ks)
n = len(P); m = np.arange(n) / 60
print(f"Edge: {n/60:.1f} min, avg {P.mean():.1f} W, coasting/zero {np.mean(P==0)*100:.1f}%, HR avg {np.nanmean(H):.1f}, cadence (pedalling) {np.nanmean(C[C>0]):.1f}")
print(f"KICKR: {len(PK)/60:.1f} min, avg {PK.mean():.1f} W; Edge started {(tk - t0)/60:.1f} min earlier")

# best efforts on both meters
for s in (5, 15, 30, 60, 120, 180, 300, 600, 1200):
    a = np.convolve(P, np.ones(s)/s, 'valid'); b = np.convolve(PK, np.ones(s)/s, 'valid')
    print(f"  best {s:>4} s: Stages {a.max():6.1f} W (ends min {(np.argmax(a)+s)/60:5.1f})   KICKR {b.max():6.1f} W")

# the final push: find the last sustained block >= 220 W (30-s mean)
r30 = np.convolve(P, np.ones(30)/30, 'same')
hi = np.where(r30 >= 220)[0]
blocks = []; s0 = hi[0]
for x, y in zip(hi[:-1], hi[1:]):
    if y - x > 10: blocks.append((s0, x)); s0 = y
blocks.append((s0, hi[-1]))
print("\nblocks with 30-s mean >= 220 W (start-end min, length, avg W, HR start/end, cadence):")
for a, b in blocks:
    seg = slice(a, b + 1)
    print(f"  min {a/60:5.1f}-{b/60:5.1f}  {b-a+1:4d} s  {P[seg].mean():6.1f} W  HR {np.nanmean(H[a:a+10]):.0f} -> {np.nanmean(H[b-9:b+1]):.0f} (max {np.nanmax(H[a:b+60 if b+60<n else n]):.0f})  cad {np.nanmean(C[seg][C[seg]>0]):.0f}")
a3 = np.convolve(P, np.ones(180)/180, 'valid'); i3 = int(np.argmax(a3))
print(f"\nbest 3 min: {a3.max():.1f} W from min {i3/60:.1f}; per 30 s: {[int(round(P[i3+k*30:i3+(k+1)*30].mean())) for k in range(6)]}; "
      f"HR {H[i3]:.0f} -> {np.nanmax(H[i3:i3+240]):.0f}; cadence {np.nanmean(C[i3:i3+180]):.0f}")
print(f"after the push: {(n - (i3+180))/60:.1f} min of riding, avg {P[i3+180:].mean():.0f} W")

# W' view (CP 175, W' 18 kJ)
w, tau = cp.wbal(P, 175, 18000, 'integral'); wd, _ = cp.wbal(P, 175, 18000, 'differential')
print(f"W'bal (CP 175, W' 18 kJ): integral min {w.min()/1000:.1f} kJ, differential min {wd.min()/1000:.1f} kJ at min {np.argmin(wd)/60:.1f}; "
      f"needed: {cp.wprime_needed(P, 175)}")
print(f"2P model prediction for 3 min at CP 175 / W' 18 kJ: {175 + 18000/180:.0f} W; W' implied by this 3 min with CP 175: {(a3.max()-175)*180/1000:.1f} kJ; with Pat's 270-275 W: {(270-175)*180/1000:.1f}-{(275-175)*180/1000:.1f} kJ")

# steady part: before the push, excluding the sprint area
pre = slice(5*60, i3 - 60)
pp, hh = P[pre], H[pre]
print(f"\nsteady part (min 5 to {i3/60-1:.0f}): avg {pp.mean():.1f} W, NP-ish, HR {np.nanmean(hh):.1f}; share of seconds: <=135 W {np.mean(pp<=135)*100:.0f}%, 136-160 {np.mean((pp>135)&(pp<=160))*100:.0f}%, >160 {np.mean(pp>160)*100:.0f}%, 0 W {np.mean(pp==0)*100:.0f}%")
half = (i3 - 60 - 300) // 2
e1 = P[300:300+half].mean()/np.nanmean(H[300:300+half]); e2 = P[300+half:i3-60].mean()/np.nanmean(H[300+half:i3-60])
print(f"decoupling of the steady part (first vs second half): {(e1/e2-1)*100:+.1f}%  (W {P[300:300+half].mean():.0f}/{P[300+half:i3-60].mean():.0f}, HR {np.nanmean(H[300:300+half]):.0f}/{np.nanmean(H[300+half:i3-60]):.0f})")
for a in range(0, n, 600):
    b = min(a+600, n); print(f"  min {a/60:3.0f}-{b/60:3.0f}: {P[a:b].mean():6.1f} W  HR {np.nanmean(H[a:b]):5.1f}  cad {np.nanmean(C[a:b][C[a:b]>0]):4.0f}  zeros {np.mean(P[a:b]==0)*100:3.0f}%")

# HR at ~130 W in this ride (comparison with check 0: 149.6 at 130 W, old fan)
sel = (np.convolve(P, np.ones(60)/60, 'same') > 120) & (np.convolve(P, np.ones(60)/60, 'same') < 140) & (np.arange(n) > 900) & (np.arange(n) < i3 - 60)
print(f"HR in 60-s windows at 120-140 W (after min 15, before the push): {np.nanmean(H[sel]):.1f} bpm over {sel.sum()} s (11 Nov check 0: 149.6 at 130 W, old fan)")

print("\nmeter comparison (power-aligned):"); mo = cp.meter_offset(gs, ks, align="power")
print("HR quality:", cp.hrv_quality(G)[1]); cp.hr_peak_clean(G)
