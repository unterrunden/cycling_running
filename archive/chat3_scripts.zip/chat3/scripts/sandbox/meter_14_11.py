import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo7/cycling_running")
import numpy as np, cp_lib as cp
gs = cp.fit_series('/home/claude/fit_14_11/14_11_garmin.fit'); ks = cp.fit_series('/home/claude/fit_14_11/14_11_kickr.fit')
t0 = int(min(gs['t'].min(), ks['t'].min())); n = int(max(gs['t'].max(), ks['t'].max())) - t0 + 1
def grid(s):
    a = np.full(n, np.nan); a[(s['t'] - t0).astype(int)] = np.nan_to_num(s['p']); return a
G, K = grid(gs), grid(ks)
# best lag by correlation of 10-s means over +-60 s
def sm(x): return np.convolve(np.nan_to_num(x), np.ones(10)/10, 'same')
both = ~np.isnan(G) & ~np.isnan(K)
best = max(((np.corrcoef(sm(G)[both][60:-60], np.roll(sm(K), l)[both][60:-60])[0,1], l) for l in range(-60, 61)))
print("lag by 10-s means: %+d s, r %.3f" % (best[1], best[0]))
lag = best[1]; Ks = np.roll(K, lag); ok = ~np.isnan(G) & ~np.isnan(Ks)
print("same window (%.1f min): Stages %.1f W, KICKR %.1f W, ratio %.3f" % (ok.sum()/60, G[ok].mean(), Ks[ok].mean(), Ks[ok].mean()/G[ok].mean()))
idx = np.where(ok)[0]
for a in range(idx[0], idx[-1], 600):
    w = ok.copy(); w[:a] = False; w[a+600:] = False
    if w.sum() > 300: print("  block from min %5.1f: Stages %6.1f  KICKR %6.1f  ratio %.3f" % ((a - idx[0])/60, G[w].mean(), Ks[w].mean(), Ks[w].mean()/G[w].mean()))
# the 3-min push on the same window
g3 = np.convolve(np.nan_to_num(G), np.ones(180)/180, 'valid'); i = int(np.argmax(g3))
print("3-min push same window: Stages %.1f, KICKR %.1f, ratio %.3f" % (np.nanmean(G[i:i+180]), np.nanmean(Ks[i:i+180]), np.nanmean(Ks[i:i+180])/np.nanmean(G[i:i+180])))
print("power-aligned meter_offset with lag search:"); cp.meter_offset(gs, ks, align="power")
def gridh(s):
    a = np.full(n, np.nan); a[(s['t'] - t0).astype(int)] = s['hr']; return a
GH, KH = gridh(gs), gridh(ks)
okh = ~np.isnan(GH) & ~np.isnan(KH)
res = []
for l in range(-120, 121):
    k = np.roll(KH, l); o = ~np.isnan(GH) & ~np.isnan(k)
    o[:150] = False; o[-150:] = False
    res.append((np.corrcoef(GH[o], k[o])[0, 1], l))
r, l = max(res); print("HR lag (MyWhoosh shifted by): %+d s, r %.3f" % (l, r))
print("power lag found: -54 s; HR lag minus power lag = %+d s (11 Nov: MyWhoosh HR about 4 s late)" % (l - (-54)))
print("meter_offset aligned by HR:"); cp.meter_offset(gs, ks, align="hr")
