import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo8/cycling_running")
import numpy as np, cp_lib as cp
_, P, H, C = cp._series_1hz(cp.fit_series('/home/claude/fit_14_11/14_11_garmin.fit'))
_, K, HK, CK = cp._series_1hz(cp.fit_series('/home/claude/fit_14_11/14_11_kickr.fit'))
def onset(x):  # start of the best 3 min, refined to the first second of the ramp
    a = np.convolve(x, np.ones(180)/180, 'valid'); i = int(np.argmax(a)); return i
iG, iK = onset(P), onset(K)
# refine the offset by correlating +-30 s around the push
seg = lambda x, i: x[i-120:i+150]
best = max((np.corrcoef(seg(P, iG), seg(K, iK + d))[0, 1], d) for d in range(-30, 31))
iK2 = iK + best[1]
print(f"push onset: Edge index {iG}, KICKR index {iK2} (refined by {best[1]:+d} s, r {best[0]:.3f}); clock offset {(iK2 - iG)}")
print("KICKR per minute in the 20 min before the push:", [int(round(K[iK2-1200+60*k:iK2-1200+60*(k+1)].mean())) for k in range(20)])
# ERG window: KICKR steady at 120 W
for mins in (15, 14, 12):
    a, b = iG - mins*60, iG - 30
    ak, bk = iK2 - mins*60, iK2 - 30
    print(f"last {mins} min before the push (minus 30 s): Stages {P[a:b].mean():.1f} W (SD of 10-s means {np.std(P[a:b][:((b-a)//10)*10].reshape(-1,10).mean(1)):.1f}), KICKR {K[ak:bk].mean():.1f} W, ratio {K[ak:bk].mean()/P[a:b].mean():.3f}; cadence {np.nanmean(C[a:b]):.0f}; HR {np.nanmean(H[a:b]):.1f}")
print(f"push on aligned windows: Stages {P[iG:iG+180].mean():.1f}, KICKR {K[iK2:iK2+180].mean():.1f}, ratio {K[iK2:iK2+180].mean()/P[iG:iG+180].mean():.3f}")
# whole overlap with this offset
off = iK2 - iG; g0 = max(0, -off); k0 = max(0, off); L = min(len(P) - g0, len(K) - k0)
print(f"whole overlap ({L/60:.1f} min): Stages {P[g0:g0+L].mean():.1f}, KICKR {K[k0:k0+L].mean():.1f}, ratio {K[k0:k0+L].mean()/P[g0:g0+L].mean():.3f}")
