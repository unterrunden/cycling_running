"""W' estimate for intervals.icu (CP = FTP = 175 W there): power-duration fits (2P CP, Morton 3P, CP fixed at 175) and W'bal simulations
(Skiba 2012 integral, Skiba 2015 differential) on Pat's hardest rides. Data: digest CSV of the 9 Nov export (per-ride bests), the export's
activity files for the key rides, tests/01_11.fit (4DP), the 11 and 12 Nov Edge files."""
import sys, os, zipfile, glob
R = "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo6/cycling_running"
sys.path.insert(0, R)
import numpy as np, pandas as pd, cp_lib as cp
from scipy.optimize import curve_fit

DUR = [("5s", 5), ("15s", 15), ("30s", 30), ("1min", 60), ("2min", 120), ("3min", 180), ("5min", 300), ("8min", 480), ("10min", 600),
       ("15min", 900), ("20min", 1200), ("30min", 1800), ("45min", 2700), ("60min", 3600)]
d = pd.read_csv(os.path.join(R, "tests/09_11_digest_rides.csv"))
out = d[d.type == "Ride"].copy()
print(f"outdoor rides with power in the digest: {out.el_5min.notna().sum()}")

# all-time bests (elapsed-based) with dates, outdoor Stages
best = {}
for lab, s in DUR:
    col = "el_" + lab; x = out[[col, "date"]].dropna()
    if len(x): i = x[col].idxmax(); best[s] = (x.loc[i, col], x.loc[i, "date"])
# add the indoor test files (Stages via the Edge): 11 Nov sprint ride, 12 Nov hour test
for f, tag in (("/home/claude/fit_11_11/11_11_garmin.fit", "2026-11-11"), ("/home/claude/fit_12_11/12_11_garmin.fit", "2026-11-12")):
    t0, P, H, C = cp._series_1hz(cp.fit_series(f))
    for lab, s in DUR:
        if len(P) >= s:
            v = np.convolve(P, np.ones(s) / s, "valid").max()
            if s not in best or v > best[s][0]: best[s] = (v, tag + " (indoor)")
print("\nBest power per duration (Stages scale, elapsed-based):")
for lab, s in DUR:
    if s in best: print(f"  {lab:>6}: {best[s][0]:6.1f} W  {best[s][1]}")

t = np.array([s for _, s in DUR if s in best], float); p = np.array([best[s][0] for _, s in DUR if s in best])

# 2-parameter CP (work = CP*t + W') on 2-15 min and 3-20 min
for lo, hi in ((120, 900), (180, 1200), (120, 1200)):
    m = (t >= lo) & (t <= hi)
    A = np.vstack([t[m], np.ones(m.sum())]).T; CPv, W = np.linalg.lstsq(A, p[m] * t[m], rcond=None)[0]
    print(f"2P CP fit {lo//60}-{hi//60} min: CP {CPv:.1f} W, W' {W/1000:.1f} kJ")

# Morton 3P: P = W'/(t - k) + CP, k = W'/(CP - Pmax)
def morton(t, CP, W, Pmax): return W / (t - W / (CP - Pmax)) + CP
m = t <= 1200
popt, _ = curve_fit(morton, t[m], p[m], p0=(175, 18000, 800), maxfev=20000)
print(f"Morton 3P fit 5 s-20 min: CP {popt[0]:.1f} W, W' {popt[1]/1000:.1f} kJ, Pmax {popt[2]:.0f} W")
pr = morton(np.array([3600.0]), *popt)[0]; print(f"   model 60-min power {pr:.1f} W vs measured 175.1 W")

# CP fixed at 175 (intervals.icu uses FTP as CP): W' implied by each duration
print("\nW' implied by each best with CP = 175 W ((P - 175) x t):")
for lab, s in DUR:
    if s in best and 60 <= s <= 1200: print(f"  {lab:>6}: {(best[s][0]-175)*s/1000:5.1f} kJ  ({best[s][1]})")
m = (t >= 120) & (t <= 900)
W175 = np.linalg.lstsq((1 / t[m])[:, None], (p[m] - 175), rcond=None)[0][0]
print(f"least-squares W' with CP fixed at 175 W, 2-15 min: {W175/1000:.1f} kJ")

# ---------------- W'bal simulations
def wbal_need(P, CP):
    """Integral (Skiba 2012): needed W' = max accumulated depletion with tau = 546*exp(-0.01*DCP)+316 (DCP from the whole ride).
    Differential (Skiba 2015): smallest W' that keeps W'bal >= 0 (bisection)."""
    P = np.nan_to_num(np.asarray(P, float))
    below = P[P < CP]; dcp = CP - below.mean() if len(below) else 0
    tau = 546 * np.exp(-0.01 * dcp) + 316; k = np.exp(-1 / tau); S = 0.0; Smax = 0.0; iS = 0
    for i, x in enumerate(P):
        S = S * k + max(0.0, x - CP)
        if S > Smax: Smax, iS = S, i
    def min_bal(W):
        b = W; mn = W
        for x in P:
            b = b - (x - CP) if x > CP else b + (CP - x) * (W - b) / W
            mn = min(mn, b)
        return mn
    lo, hi = 1000.0, 60000.0
    if min_bal(hi) < 0: dif = float("inf")
    else:
        for _ in range(30):
            mid = (lo + hi) / 2
            lo, hi = (mid, hi) if min_bal(mid) < 0 else (lo, mid)
        dif = hi
    return Smax, iS, tau, dif

# key rides from the export
zips = sorted(glob.glob(os.path.join(R, "strava_export_*.zip")))
X = "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/export_rides"; os.makedirs(X, exist_ok=True)
z = zipfile.ZipFile(zips[-1]); names = z.namelist()
key = {}
for lab in ("1min", "2min", "3min", "5min", "8min", "10min", "15min", "20min"):
    s = dict(DUR)[lab]; col = "el_" + lab; x = out[[col, "date", "file"]].dropna()
    for _, r in x.sort_values(col, ascending=False).head(2).iterrows(): key[r["file"]] = r["date"]
files = {}
for f, dt in key.items():
    hit = [n for n in names if n.endswith("/" + f) or n == f]
    if hit:
        dst = os.path.join(X, os.path.basename(hit[0]))
        if not os.path.exists(dst): open(dst, "wb").write(z.read(hit[0]))
        files[dst] = dt
files[os.path.join(R, "tests/01_11.fit")] = "2026-11-01 (4DP file)"
files["/home/claude/fit_11_11/11_11_garmin.fit"] = "2026-11-11 (indoor)"
files["/home/claude/fit_12_11/12_11_garmin.fit"] = "2026-11-12 (hour test)"
print("\nW' needed so that W'bal never drops below 0 (CP = 175 W; and CP = 180 W):")
rows = []
for f, dt in sorted(files.items(), key=lambda kv: kv[1]):
    try:
        a, ex, tl = cp.load_activity(f); P = np.nan_to_num(tl["P"])
    except Exception as e:
        print("  skip", f, e); continue
    r175 = wbal_need(P, 175); r180 = wbal_need(P, 180)
    rows.append((dt, os.path.basename(f), r175, r180))
    print(f"  {dt:24s} integral {r175[0]/1000:5.1f} kJ (at min {r175[1]/60:5.1f}, tau {r175[2]:.0f} s) | differential {r175[3]/1000:5.1f} kJ"
          f"   || CP 180: integral {r180[0]/1000:5.1f}, differential {r180[3]/1000:5.1f} kJ")
