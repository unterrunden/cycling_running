"""Compare committed repo files with the handover copies: final newline and byte equality."""
import os
REPO = "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo6/cycling_running"
OUT, DOCS = "/home/claude/repo_out", "/home/claude/docs"
pairs = {f: os.path.join(OUT, f) for f in ("analysis_tools.py", "cp_lib.py", "selfcheck.py", "README.md", "SCRIPT_CATALOGUE.md", "segments_tool.py")}
pairs.update({"docs/" + f: os.path.join(DOCS, f) for f in ("coach_notes.md", "project_memory_mirror.md", "routes_and_courses.md", "history_digest.md")})
pairs["docs/segments.md"] = os.path.join(DOCS, "claude", "segments.md")
for f, mine in pairs.items():
    a = open(os.path.join(REPO, f), "rb").read(); b = open(mine, "rb").read()
    print("%-32s repo ends with newline: %-5s  mine: %-5s  byte-identical: %s" % (f, a.endswith(b"\n"), b.endswith(b"\n"), a == b))
