import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/tk"); import cp_lib as cp
f = "/home/claude/tk/tests/21_11_garmin.fit"
x = cp.session_1hz(f, "ride"); a, ex, tl = cp.load_activity(f)
P, H, C, V, D, m = x["P"], x["H"], x["C"], x["V"], x["D"], x["mov"]
n = len(P); print("len s", n, "rec", int(tl["rec"].sum()), "moving", int(m.sum()), "dist km", np.nanmax(D) / 1000)
L = cp.ride_load(x, 175.0); print({k: round(v, 2) if isinstance(v, float) else v for k, v in L.items()})
print("hr", cp.hr_stats(x)); print("dec", cp.aero_decoupling(x, "ride", 175.0), "EF", round(cp.efficiency_factor(x, "ride"), 3))
print("HRR", [(round(t / 60, 1), round(h), round(d, 1), c) for t, h, d, c in cp.hrr_events(x, "ride", 175.0)])
print("artefact scan", cp.hr_artefact_scan(dict(P=P, H=H, S=np.where(m, 2.0, 0.0))), "gaps", cp.hr_gaps(tl)[:10])
# stops
stop = ~m; runs = []; i = 0
while i < n:
    if stop[i]:
        j = i
        while j < n and stop[j]: j += 1
        if j - i >= 20: runs.append((round(i / 60, 1), j - i, round(D[min(i, n - 1)] / 1000, 1)))
        i = j
    else: i += 1
print("stops >=20 s (min, s, km):", runs, "total stopped s", int(stop.sum()))
# per 15 min of moving time
idx = np.where(m)[0]; seg = 900
print("per 15 min moving: start_min, km, avg W, NP, HR, cad, speed")
for k in range(0, len(idx), seg):
    s = idx[k:k + seg]
    if len(s) < 120: continue
    print("  %5.1f %5.1f %4.0f %4.0f %4.0f %3.0f %4.1f" % (s[0] / 60, D[s[0]] / 1000, P[s].mean(), cp.norm_power(P[s]), np.nanmean(H[s]), np.nanmean(C[s][C[s] > 0]), np.mean(V[s]) * 3.6))
# time in power bands (moving)
pm = P[m]; print("share <=135 W %.0f%%, 136-157 %.0f%%, >157 %.0f%%, >=200 %.0f%%, coasting(0) %.0f%%" % (np.mean(pm <= 135) * 100, np.mean((pm > 135) & (pm <= 157)) * 100, np.mean(pm > 157) * 100, np.mean(pm >= 200) * 100, np.mean(pm == 0) * 100))
# bests in the file
for w in (5, 15, 30, 60, 180, 300, 600, 1200, 1800, 3600):
    c = np.convolve(P, np.ones(w) / w, "valid"); i0 = int(np.argmax(c)); print("  best %5d s %6.1f W at min %.1f (km %.1f)" % (w, c[i0], i0 / 60, D[i0] / 1000))
# temperature (edge), altitude
print("temp edge", np.nanmean(np.asarray(tl.get("T", np.full(n, np.nan)), float)) if "T" in tl else "n/a")
alt = np.asarray(a[:, 3], float) if a.shape[1] > 3 else None
print("a cols", a.shape)
