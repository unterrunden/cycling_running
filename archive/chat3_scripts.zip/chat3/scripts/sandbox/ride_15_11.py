import sys; sys.path.insert(0, "/tmp/claude-0/-home-claude/c7d54ae7-4606-5d7f-9600-437e03961c74/scratchpad/repo9/cycling_running")
import numpy as np, cp_lib as cp
G, K = "/home/claude/fit_15_11/15_11_garmin.fit", "/home/claude/fit_15_11/15_11_kickr.fit"
gs, ks = cp.fit_series(G), cp.fit_series(K)
print(cp.fit_laps(G).to_string())
mo = cp.meter_offset(gs, ks, align="power")
cp.segment_lags(gs, ks)
