"""Sunset / civil dusk for Brühl (NOAA sunrise equation, own implementation)."""
import math, datetime as dt

LAT, LON = 50.83, 6.89   # near Pat's home (C8 start 50.8384 N, 6.8885 E)
TZ = 1                    # CET (no DST in November)

def event(d, zenith, rising):
    n = d.timetuple().tm_yday
    lng_hour = LON / 15
    t = n + ((6 if rising else 18) - lng_hour) / 24
    M = 0.9856 * t - 3.289
    L = (M + 1.916 * math.sin(math.radians(M)) + 0.020 * math.sin(math.radians(2 * M)) + 282.634) % 360
    RA = math.degrees(math.atan(0.91764 * math.tan(math.radians(L)))) % 360
    RA = (RA + (math.floor(L / 90) * 90 - math.floor(RA / 90) * 90)) / 15
    sin_dec = 0.39782 * math.sin(math.radians(L)); cos_dec = math.cos(math.asin(sin_dec))
    cos_h = (math.cos(math.radians(zenith)) - sin_dec * math.sin(math.radians(LAT))) / (cos_dec * math.cos(math.radians(LAT)))
    H = (360 - math.degrees(math.acos(cos_h))) if rising else math.degrees(math.acos(cos_h))
    T = H / 15 + RA - 0.06571 * t - 6.622
    UT = (T - lng_hour) % 24
    loc = (UT + TZ) % 24
    return f"{int(loc):02d}:{int(round((loc % 1) * 60)) % 60:02d}"

for day in [10, 11, 12, 13, 14, 15, 16, 20, 22, 29]:
    d = dt.date(2026, 11, day)
    print(d.strftime("%a %d %b"), "sunset", event(d, 90.833, False), "| civil dusk", event(d, 96, False))
for day in [6, 13, 20]:
    d = dt.date(2026, 12, day)
    print(d.strftime("%a %d %b"), "sunset", event(d, 90.833, False), "| civil dusk", event(d, 96, False))
