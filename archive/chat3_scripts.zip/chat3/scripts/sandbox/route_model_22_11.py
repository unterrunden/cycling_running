import sys, numpy as np
sys.path.insert(0,'/home/claude/tk'); import routes_tool as rt, cp_lib as cp
def model(f, P, wind_kmh=0.0, wind_from=0.0, vmax=42.0, corner_s=4.0, **kw):
    r=rt.analyse(f); s=r['s']; e=r['rel']; b=r['b']; t=0.0; T=[0.0]
    for i in range(len(s)-1):
        ds=s[i+1]-s[i]; gr=(e[i+1]-e[i])/ds if ds>0 else 0
        head=wind_kmh*np.cos(np.radians(b[i]-wind_from))
        v=min(cp.speed_from_power(P, gr, head, **kw), vmax); t+=ds/(v/3.6); T.append(t)
    return t+corner_s*len(r['turns']), r['km'], np.array(T), s
if __name__=='__main__':
    for rho in (1.22,1.27):
        t21,km21,_,_=model(sys.argv[2],144.7,rho=rho)
        print('21 Nov model rho %.2f: %.0f s (%.1f km/h) vs actual 8785 s (%.1f km/h) -> factor %.3f'%(rho,t21,km21/t21*3600,60.38/8785*3600,8785/t21))
    k=8785/model(sys.argv[2],144.7,rho=1.27)[0]
    for P in (115,120,125,130,145):
        for wf,wk in ((0,0),(62,8.5)):
            t,km,T,s=model(sys.argv[1],P,wk,wf,rho=1.27)
            i55=np.argmin(abs(s-55200))
            print('Sun %.1f km at %d W %s: model %.0f min (%.1f km/h); x%.3f -> %.0f min moving (%.1f km/h); km 55.2 at %.0f min'%(km,P,'ENE 8.5' if wk else 'calm',t/60,km/t*3600,k,t*k/60,km/(t*k)*3600,T[i55]*k/60))
