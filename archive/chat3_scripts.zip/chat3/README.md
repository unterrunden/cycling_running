# Chat 3 script archive (cycling | running 3, 10-22 Nov 2026)

Made by Claude on 22 Nov from what the session could still see; the dispositions are in SCRIPT_CATALOGUE.md.

- `scripts/sandbox/`: ad hoc script files of chat 3 that survived in the sandbox (10-22 Nov): run_10_11, sun, normalize, ride_11_11 (a-c),
  rr_peak, eol_check, hour_12_11, wprime, ride_14_11, meter_14_11, erg_14_11, mo_test, ride_15_11 (a-c), ride_21_11 (was r21.py),
  route_model_22_11 (was c30/model.py), mirror_restructure_21_11. Scripts of 16-19 Nov (e.g. fit_18_11/an.py) were lost in a sandbox reset.
- `scripts/overhaul_20_11/`: the digest-v2 prototypes of 20 Nov (ported into cp_lib v1.15 METRICS and digest_tool.py).
- `commands/`: every Bash command and file write of 21 Nov 18:29 - 22 Nov 21:28 (253 files, named dd_mm.hh_mm[.n], local time; the
  packing of this archive and the final handover came after it) from the session transcript, with `INDEX.tsv` (tool, category, where it went). Commands of 10-21 Nov before the last context reset are not in the
  transcript any more; their dispositions were catalogued day by day in SCRIPT_CATALOGUE.md when they ran.
- Paths inside the scripts point to the sandbox (/home/claude/..., the scratchpad): they document the work, they are not meant to run as is.
